import {filterCandidatesByYear} from './year-filter.mjs';

export function representativeCandidates(candidates,maxSamples=5){
  if(candidates.length<=maxSamples)return [...candidates];
  const indexes=[0,...Array.from({length:maxSamples-2},(_,i)=>Math.round((i+1)*(candidates.length-1)/(maxSamples-1))),candidates.length-1];
  return [...new Set(indexes)].map(index=>candidates[index]);
}

function words(item){return item?.wordCount||item?.words||((item?.contentBlocks||item?.previewBlocks||[]).filter(block=>block.text).map(block=>block.text).join(' ').trim().split(/\s+/).filter(Boolean).length)||0}
function images(item){return item?.imageReferences||item?.blocks?.filter(block=>block.type==='image')||item?.contentBlocks?.filter(block=>block.type==='image')||[]}
function bytesOf(ref){return Number(ref?.bytes||ref?.byteLength||ref?.size||0)}

export function estimateEpubSize(candidates,{mode='optimized',cachedItems=[],maxSamples=5}={},currentYear=new Date().getFullYear()){
  const selected=candidates, samples=representativeCandidates(selected,maxSamples),byUrl=new Map(cachedItems.map(item=>[item.canonicalUrl,item]));
  const measured=samples.map(candidate=>({candidate,item:byUrl.get(candidate.canonicalUrl)||candidate})).filter(({item})=>words(item)>0||images(item).length>0);
  if(!measured.length)return {reliable:false,message:'Not enough information for a reliable estimate.',selected:selected.length,sampled:0,mode};
  const totalWords=measured.reduce((n,x)=>n+words(x.item),0),totalImages=measured.reduce((n,x)=>n+images(x.item).length,0),knownImageBytes=measured.reduce((n,x)=>n+images(x.item).reduce((m,ref)=>m+bytesOf(ref),0),0),scale=selected.length/measured.length;
  const textBytes=totalWords*6*scale+selected.length*2400;
  const imageBytes=mode==='text-only'?0:(knownImageBytes?knownImageBytes*scale:totalImages*scale*(mode==='original'?250000:90000));
  const estimate=Math.max(0,Math.round(textBytes+imageBytes+selected.length*1800+2000));
  const low=Math.max(0,Math.round(estimate*.65)),high=Math.round(estimate*1.45);
  return {reliable:true,mode,selected:selected.length,sampled:measured.length,words:Math.round(totalWords*scale),images:Math.round(totalImages*scale),knownImageBytes,lowBytes:low,highBytes:high,range:`${formatBytes(low)}–${formatBytes(high)}`,message:`Based on ${measured.length} of ${selected.length} selected articles; image-heavy posts and GIFs can change the result.`};
}

export function estimateForFilter(candidates,filter,options,currentYear=new Date().getFullYear()){
  return estimateEpubSize(filterCandidatesByYear(candidates,filter,currentYear).candidates,options,currentYear);
}
export function formatBytes(bytes){if(bytes<1024)return `${bytes} B`;if(bytes<1024**2)return `${Math.round(bytes/1024)} KB`;return `${(bytes/1024**2).toFixed(1)} MB`}
