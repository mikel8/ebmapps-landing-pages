import {FOUNDING_ACCESS_PRICE_CENTS, FOUNDING_ACCESS_PRODUCT} from './billing.mjs';

export const FOUNDER_ACCESS_FLAG = 'BTB_ENFORCE_FOUNDER_ACCESS';

export function foundingAccessEnabled(env = process.env) {
  return /^(1|true|yes|on)$/i.test(env[FOUNDER_ACCESS_FLAG] || '');
}

export function foundingOffer() {
  return {
    productKey: FOUNDING_ACCESS_PRODUCT,
    priceCents: FOUNDING_ACCESS_PRICE_CENTS,
    currency: 'usd',
    label: 'BlogToBook Founding Access',
    summary: '$19 one-time payment. No subscription. It unlocks additional eligible EPUB exports within BlogToBook’s existing hosted safety limits.'
  };
}

// The export route is the authority. The browser may show this state, but it
// cannot make an export paid or free by changing local storage.
export function exportAccess({enabled, entitlement, firstExportClaimed = false} = {}) {
  if (!enabled) return {allowed: true, kind: 'feature_disabled'};
  if (entitlement?.status === 'active' && entitlement?.product_key === FOUNDING_ACCESS_PRODUCT) return {allowed: true, kind: 'founding_access'};
  if (firstExportClaimed) return {allowed: true, kind: 'first_free_export'};
  return {allowed: false, kind: 'founding_access_required', offer: foundingOffer()};
}
