const PROMO = /\b(?:subscribe|newsletter|sign\s*up|signup|join|follow|social|referr|support|sponsor|discount|free\s+trial|share\s+this|read\s+more)\b/i;

function normalized(text) {
  return String(text || '').toLowerCase()
    .replace(/https?:\/\/\S+/g, ' url ')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim().replace(/\s+/g, ' ');
}

function blocksFor(article) { return article.contentBlocks || article.blocks || []; }

/** Remove only repeated, promotional suffix blocks. The input records are never mutated. */
export function cleanPromotionalFooters(articles, { enabled = true } = {}) {
  const source = articles || [];
  if (!enabled) return { articles: source.map(a => ({ ...a, blocks: blocksFor(a).map(b => ({ ...b })), ...(a.contentBlocks ? { contentBlocks: blocksFor(a).map(b => ({ ...b })) } : {}) })), stats: { enabled: false, patternsDetected: 0, articleFootersRemoved: 0, blocksRemoved: 0, articlesUnchanged: source.length, examples: [] } };

  const counts = new Map();
  for (const article of source) {
    for (const block of blocksFor(article).slice(-3)) {
      if (block.type === 'image' || typeof block.text !== 'string') continue;
      const key = normalized(block.text);
      if (key && key.length >= 20 && key.length <= 800 && PROMO.test(block.text)) counts.set(key, (counts.get(key) || 0) + 1);
    }
  }
  const repeated = new Set([...counts].filter(([, count]) => count >= 2).map(([key]) => key));
  let articleFootersRemoved = 0, blocksRemoved = 0;
  const examples = [];
  const cleaned = source.map(article => {
    const original = blocksFor(article);
    let cut = original.length;
    while (cut > 0) {
      const block = original[cut - 1];
      if (block.type === 'image' || typeof block.text !== 'string' || !repeated.has(normalized(block.text))) break;
      cut -= 1;
    }
    const removed = original.slice(cut);
    if (!removed.length) return { ...article, blocks: original.map(b => ({ ...b })), contentBlocks: article.contentBlocks ? original.map(b => ({ ...b })) : undefined };
    articleFootersRemoved += 1; blocksRemoved += removed.length;
    if (examples.length < 3) examples.push({ before: removed[0].text, after: '' });
    const next = original.slice(0, cut).map(b => ({ ...b }));
    return { ...article, blocks: next, contentBlocks: article.contentBlocks ? next : undefined };
  });
  return { articles: cleaned, stats: { enabled: true, patternsDetected: repeated.size, articleFootersRemoved, blocksRemoved, articlesUnchanged: source.length - articleFootersRemoved, examples } };
}
