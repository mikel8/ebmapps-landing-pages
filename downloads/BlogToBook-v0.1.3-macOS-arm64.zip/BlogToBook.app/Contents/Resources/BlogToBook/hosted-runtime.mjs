import {randomBytes} from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

export const HOSTED_LIMITS={
  maxArchivePages:100,
  maxCandidates:5000,
  maxCrawledArticles:100,
  maxImages:100,
  maxImageBytes:25*1024*1024,
  maxOutboundBytes:50*1024*1024,
  jobDeadlineMs:15*60*1000
};

const TERMINAL=new Set(['COMPLETE','FAILED','CANCELLED']);
const TRANSITIONS={
  SUBMITTED:new Set(['INSPECTING','FAILED','CANCELLED']),
  INSPECTING:new Set(['READY','FAILED','CANCELLED']),
  READY:new Set(['INSPECTING','CRAWLING','FAILED','CANCELLED']),
  CRAWLING:new Set(['REVIEW','FAILED','CANCELLED']),
  REVIEW:new Set(['EXPORTING','FAILED','CANCELLED']),
  EXPORTING:new Set(['COMPLETE','FAILED','CANCELLED']),
  COMPLETE:new Set(), FAILED:new Set(), CANCELLED:new Set()
};
const CAPABILITY=/^[A-Za-z0-9_-]{32,128}$/;
const json=value=>JSON.stringify(value,null,2);
// Capability IDs are base64url values, so `_` is valid. Artifact filenames
// deliberately use a narrower, traversal-safe alphabet.
export const hostedArtifactName=id=>`blogtobook-${String(id).slice(0,12).replace(/_/g,'-').toLowerCase()}.epub`;

export class HostedRuntime {
  constructor({root,limits={},now=()=>Date.now(),retention={}}={}){
    if(!root)throw Error('Hosted runtime requires a storage root');
    this.root=path.resolve(root);this.jobsRoot=path.join(this.root,'jobs');this.now=now;
    this.limits={...HOSTED_LIMITS,...limits};
    this.retention={completedMs:24*60*60*1000,failedMs:60*60*1000,artifactMs:60*60*1000,...retention};
  }
  async init(){await fs.mkdir(this.jobsRoot,{recursive:true});return this}
  capability(){return randomBytes(32).toString('base64url')}
  valid(id){return typeof id==='string'&&CAPABILITY.test(id)}
  jobDir(id){if(!this.valid(id))throw Error('Job not found');return path.join(this.jobsRoot,id)}
  file(id,name){if(!/^[a-z][a-z0-9-]*\.json$/i.test(name))throw Error('Invalid job file');return path.join(this.jobDir(id),name)}
  async atomic(file,value){const tmp=`${file}.${randomBytes(8).toString('hex')}.tmp`;await fs.writeFile(tmp,json(value));await fs.rename(tmp,file)}
  async create({source}={}){const id=this.capability(),createdAt=this.now(),dir=this.jobDir(id);await fs.mkdir(path.join(dir,'images'),{recursive:true});await fs.mkdir(path.join(dir,'artifacts'),{recursive:true});const job={id,state:'SUBMITTED',createdAt,updatedAt:createdAt,source,limits:this.limits,progress:{total:0,processed:0,success:0,reused:0,previews:0,previewsReused:0,failed:0,cancelled:0},cancellation:{requested:false},artifact:null,error:null,resources:null};await this.atomic(this.file(id,'job.json'),job);await this.atomic(this.file(id,'candidates.json'),[]);await this.atomic(this.file(id,'articles.json'),[]);await this.atomic(this.file(id,'assets.json'),[]);await this.atomic(this.file(id,'outcomes.json'),[]);return job}
  async read(id){try{return JSON.parse(await fs.readFile(this.file(id,'job.json'),'utf8'))}catch{throw Error('Job not found')}}
  async write(job){job.updatedAt=this.now();await this.atomic(this.file(job.id,'job.json'),job);return job}
  async transition(id,state,patch={}){const job=await this.read(id);if(!TRANSITIONS[job.state]?.has(state))throw Error(`Illegal hosted job transition: ${job.state} -> ${state}`);Object.assign(job,patch,{state});return this.write(job)}
  async patch(id,patch={}){const job=await this.read(id);if(TERMINAL.has(job.state)&&patch.state)throw Error('Cannot modify terminal hosted job state');Object.assign(job,patch);return this.write(job)}
  async requestCancel(id){const job=await this.read(id);if(TERMINAL.has(job.state))return job;return this.transition(id,'CANCELLED',{cancellation:{requested:true,requestedAt:this.now()}})}
  async writeJson(id,name,value){await this.atomic(this.file(id,name),value)}
  async readJson(id,name){try{return JSON.parse(await fs.readFile(this.file(id,name),'utf8'))}catch{throw Error('Job not found')}}
  async writeArtifact(id,name,bytes){if(!/^[a-z0-9-]+\.epub$/i.test(name))throw Error('Invalid artifact');const job=await this.read(id),file=path.join(this.jobDir(id),'artifacts',name);await fs.writeFile(file,bytes);job.artifact={name,createdAt:this.now(),expiresAt:this.now()+this.retention.artifactMs};await this.write(job);return job.artifact}
  async readArtifact(id,name){const job=await this.read(id);if(!job.artifact||job.artifact.name!==name||job.artifact.expiresAt<=this.now())throw Error('Artifact not found');try{return await fs.readFile(path.join(this.jobDir(id),'artifacts',name))}catch{throw Error('Artifact not found')}}
  status(job){return {jobId:job.id,state:job.state,createdAt:job.createdAt,updatedAt:job.updatedAt,progress:job.progress,cancellation:job.cancellation,error:job.error?{category:job.error.category,message:job.error.message}:null,limits:job.limits,resources:job.resources||null,inspection:job.inspection||null,review:job.review||null,export:job.export||null,artifact:job.artifact&&job.artifact.expiresAt>this.now()?{name:job.artifact.name,expiresAt:job.artifact.expiresAt}:null}}
  async recoverInterrupted(){let changed=0;for(const id of await this.ids()){const job=await this.read(id);if(['INSPECTING','CRAWLING','EXPORTING'].includes(job.state)){await this.transition(id,'FAILED',{error:{category:'INTERRUPTED_RESTART',message:'Processing was interrupted by a service restart.'}});changed++}}return changed}
  async ids(){try{return (await fs.readdir(this.jobsRoot,{withFileTypes:true})).filter(x=>x.isDirectory()&&this.valid(x.name)).map(x=>x.name)}catch{return []}}
  async cleanup(now=this.now()){const removed=[],artifacts=[];for(const id of await this.ids()){let job;try{job=await this.read(id)}catch{continue}if(job.artifact&&job.artifact.expiresAt<=now){await fs.rm(path.join(this.jobDir(id),'artifacts',job.artifact.name),{force:true});job.artifact=null;await this.write(job);artifacts.push(id)}const age=now-job.updatedAt,ttl=job.state==='FAILED'||job.state==='CANCELLED'?this.retention.failedMs:this.retention.completedMs;if((TERMINAL.has(job.state)&&age>=ttl)||(!TERMINAL.has(job.state)&&age>=this.retention.failedMs)){await fs.rm(this.jobDir(id),{recursive:true,force:true});removed.push(id)}}return {removed,artifacts}}
}

export async function createHostedRuntime(options){return new HostedRuntime(options).init()}
