// Coverage is derived from the primary archive path, not from a limited feed.
export function assessCompleteness({candidateCount,primary,candidateLimitReached=false,supplementaryConflict=false}={}){
 const termination=candidateLimitReached?'CANDIDATE_LIMIT':primary?.terminationReason||'NO_CONTINUATION_EVIDENCE';
 const knownGap=['PAGE_LIMIT','CANDIDATE_LIMIT','FETCH_FAILED','REDIRECT_BLOCKED','PAGINATION_LOOP','UNSUPPORTED_CONTINUATION','REPEATED_CONTENT','STRUCTURE_MISMATCH'].includes(termination);
 if(!candidateCount&&primary?.verifiedEmpty===true&&primary?.boundaryEvidence&&!knownGap)return {status:'COMPLETE',reason:primary.boundaryEvidence,verified:true,inferred:false};
 if(!candidateCount)return {status:'FAILED',reason:termination,verified:false,inferred:false};
 if(knownGap)return {status:'PARTIAL',reason:termination,verified:false,inferred:false};
 if(primary?.continuationRequestsFailed)return {status:'PARTIAL',reason:'FETCH_FAILED',verified:false,inferred:false};
 if(supplementaryConflict)return {status:'UNKNOWN',reason:'SUPPLEMENTARY_SOURCE_CONFLICT',verified:false,inferred:true};
 const boundary=primary?.boundaryEvidence;
 if(termination==='EXHAUSTED_VERIFIED'&&boundary&&!primary?.continuationRequestsFailed&&!primary?.limitsReached?.page&&!primary?.limitsReached?.candidate)return {status:'COMPLETE',reason:boundary,verified:true,inferred:false};
 return {status:'UNKNOWN',reason:termination,verified:false,inferred:true};
}
