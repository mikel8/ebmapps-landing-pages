import {createFoundingAccessCheckout} from './checkout.mjs';
import {processStripeEvent, verifyStripeSignature, FOUNDING_ACCESS_PRODUCT} from './billing.mjs';
import https from 'node:https';
import {hashPurchaseEmail} from './billing-recovery.mjs';

async function responseJson(response){
  if(typeof response.json==='function') return response.json();
  return JSON.parse(await response.text());
}
function stripePost(body, headers){return new Promise((resolve,reject)=>{const req=https.request('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers},res=>{const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>{const text=Buffer.concat(chunks).toString('utf8');resolve({ok:res.statusCode>=200&&res.statusCode<300,status:res.statusCode,json:async()=>JSON.parse(text),text:async()=>text})})});req.on('error',reject);req.end(String(body))})}
function supabaseRequest(url,options){return new Promise((resolve,reject)=>{const target=new URL(url);const req=https.request(target,{method:options.method||'GET',headers:options.headers||{}},res=>{const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>{const text=Buffer.concat(chunks).toString('utf8');resolve({ok:res.statusCode>=200&&res.statusCode<300,status:res.statusCode,json:async()=>text?JSON.parse(text):null,text:async()=>text})})});req.on('error',reject);if(options.body)req.write(String(options.body));req.end()})}

export function billingEnabled(env=process.env){return Boolean(env.STRIPE_SECRET_KEY&&env.BLOGTOBOOK_STRIPE_PRICE_ID&&env.BLOGTOBOOK_SUPABASE_URL&&env.BLOGTOBOOK_SUPABASE_SERVICE_ROLE_KEY)}
export async function createHostedCheckout({ownerKey,analyticsId=null,trafficClass=null,env=process.env,fetchImpl=null}){
  if(!billingEnabled(env))throw new Error('Billing is not configured');
  const stripe={checkout:{sessions:{create:async payload=>{const body=new URLSearchParams();for(const [k,v] of Object.entries(payload)){if(k==='line_items'){body.set('line_items[0][price]',v[0].price);body.set('line_items[0][quantity]',String(v[0].quantity));}else if(k==='metadata'){for(const [mk,mv] of Object.entries(v))body.set(`metadata[${mk}]`,mv);}else if(k==='payment_intent_data'){for(const [mk,mv] of Object.entries(v.metadata||{}))body.set(`payment_intent_data[metadata][${mk}]`,mv)}else if(v!==undefined)body.set(k,v)}const headers={authorization:`Bearer ${env.STRIPE_SECRET_KEY}`,'content-type':'application/x-www-form-urlencoded'};const r=fetchImpl?await fetchImpl('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers,body}):await stripePost(body,headers);if(!r.ok)throw Error('Stripe checkout creation failed');return responseJson(r)}}}};
  return createFoundingAccessCheckout(stripe,{ownerKey,analyticsId,trafficClass,env});
}
export function supabaseBillingStoreFromEnv(env=process.env,fetchImpl=null){
  const base=`${env.BLOGTOBOOK_SUPABASE_URL}/rest/v1`,headers={apikey:env.BLOGTOBOOK_SUPABASE_SERVICE_ROLE_KEY,authorization:`Bearer ${env.BLOGTOBOOK_SUPABASE_SERVICE_ROLE_KEY}`,'content-type':'application/json'};
  async function request(path,options={}){const requestOptions={...options,headers:{...headers,...options.headers}};const r=fetchImpl?await fetchImpl(base+path,requestOptions):await supabaseRequest(base+path,requestOptions);if(!r.ok)throw Error(`Supabase billing request failed (${r.status})`);return r.status===204?null:responseJson(r)}
  return {
    hasEvent:async id=>(await request(`/blogtobook_webhook_events?select=stripe_event_id&stripe_event_id=eq.${encodeURIComponent(id)}&limit=1`)).length>0,
    recordEvent:(id,d={})=>request('/blogtobook_webhook_events?on_conflict=stripe_event_id',{method:'POST',headers:{prefer:'resolution=merge-duplicates'},body:JSON.stringify({stripe_event_id:id,event_type:d.eventType||null})}),
    grant:(owner,d={})=>request('/blogtobook_entitlements?on_conflict=owner_key,product_key',{method:'POST',headers:{prefer:'resolution=merge-duplicates'},body:JSON.stringify({owner_key:owner,product_key:FOUNDING_ACCESS_PRODUCT,stripe_customer_id:d.customerId||null,stripe_session_id:d.sessionId||null,stripe_payment_intent_id:d.paymentIntentId||null,checkout_reference_id:d.referenceId||null,purchase_email_hash:d.emailHash||null,status:'active'})}),
    backfillEmailHash:(owner,emailHash,sessionId)=>request(`/blogtobook_entitlements?owner_key=eq.${encodeURIComponent(owner)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}&stripe_session_id=eq.${encodeURIComponent(sessionId||'')}`,{method:'PATCH',body:JSON.stringify({purchase_email_hash:emailHash})}),
    revoke:owner=>request(`/blogtobook_entitlements?owner_key=eq.${encodeURIComponent(owner)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}`,{method:'PATCH',body:JSON.stringify({status:'revoked'})}),
    findEntitlementByPaymentIntent:async paymentIntent=>{const rows=await request(`/blogtobook_entitlements?select=owner_key,product_key,status&stripe_payment_intent_id=eq.${encodeURIComponent(paymentIntent)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}&limit=1`);return rows[0]||null},
    getEntitlement:async owner=>{const rows=await request(`/blogtobook_entitlements?select=owner_key,product_key,status,first_export_used&owner_key=eq.${encodeURIComponent(owner)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}&limit=1`);if(rows[0])return rows[0];const aliases=await request(`/blogtobook_entitlement_aliases?select=entitlement_owner_key,product_key&owner_key=eq.${encodeURIComponent(owner)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}&limit=1`);if(!aliases[0])return null;const originals=await request(`/blogtobook_entitlements?select=owner_key,product_key,status,first_export_used&owner_key=eq.${encodeURIComponent(aliases[0].entitlement_owner_key)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}&status=eq.active&limit=1`);return originals[0]||null},
    getCheckout:async owner=>{const rows=await request(`/blogtobook_checkout_sessions?select=stripe_session_id,checkout_url,expires_at&owner_key=eq.${encodeURIComponent(owner)}&limit=1`);return rows[0]||null},
    saveCheckout:(owner,d={})=>request('/blogtobook_checkout_sessions?on_conflict=owner_key',{method:'POST',headers:{prefer:'resolution=merge-duplicates'},body:JSON.stringify({owner_key:owner,stripe_session_id:d.sessionId,checkout_url:d.checkoutUrl,expires_at:d.expiresAt})}),
    // These RPCs make the free allowance atomic across refreshes and duplicate
    // export clicks. A failed export releases only its own pending claim.
    claimFirstExport:async(owner,claimId)=>Boolean((await request('/rpc/blogtobook_claim_first_export',{method:'POST',body:JSON.stringify({p_owner_key:owner,p_claim_id:claimId})}))),
    finalizeFirstExport:(owner,claimId)=>request('/rpc/blogtobook_finalize_first_export',{method:'POST',body:JSON.stringify({p_owner_key:owner,p_claim_id:claimId})}),
    releaseFirstExport:(owner,claimId)=>request('/rpc/blogtobook_release_first_export',{method:'POST',body:JSON.stringify({p_owner_key:owner,p_claim_id:claimId})}),
    markFirstExport:owner=>request(`/blogtobook_entitlements?owner_key=eq.${encodeURIComponent(owner)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}`,{method:'PATCH',body:JSON.stringify({first_export_used:true})})
    ,findActiveByEmailHash:async emailHash=>{const rows=await request(`/blogtobook_entitlements?select=owner_key,product_key,status&purchase_email_hash=eq.${encodeURIComponent(emailHash)}&product_key=eq.${FOUNDING_ACCESS_PRODUCT}&status=eq.active&limit=1`);return rows[0]||null}
    ,issueRecovery:(d={})=>request('/blogtobook_recovery_tokens',{method:'POST',body:JSON.stringify({recovery_id:d.recoveryId,email_hash:d.emailHash,token_hash:d.tokenHash,expires_at:d.expiresAt})})
    ,consumeRecovery:async d=>{const rows=await request('/rpc/blogtobook_consume_recovery',{method:'POST',body:JSON.stringify({p_recovery_id:d.recoveryId,p_token_hash:d.tokenHash})});return Array.isArray(rows)?rows[0]||null:rows||null}
    ,linkOwner:(d={})=>request('/blogtobook_entitlement_aliases?on_conflict=owner_key',{method:'POST',headers:{prefer:'resolution=merge-duplicates'},body:JSON.stringify({owner_key:d.ownerKey,entitlement_owner_key:d.entitlementOwnerKey,product_key:d.productKey})})
  };
}
export async function handleBillingWebhook({payload,signature,env=process.env,fetchImpl=null}){if(!env.BLOGTOBOOK_STRIPE_WEBHOOK_SECRET)throw Error('Billing webhook is not configured');if(!verifyStripeSignature(payload,signature,env.BLOGTOBOOK_STRIPE_WEBHOOK_SECRET))throw Error('Invalid Stripe signature');return processStripeEvent(JSON.parse(payload),supabaseBillingStoreFromEnv(env,fetchImpl),{emailHashSecret:env.BLOGTOBOOK_RECOVERY_HASH_SECRET});}
