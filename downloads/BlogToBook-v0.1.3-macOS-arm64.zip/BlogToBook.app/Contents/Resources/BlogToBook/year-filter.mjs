const DATE_RE=/^(\d{4})(?:-\d{2}-\d{2})?/;

function yearOf(candidate){
  const value=candidate?.publicationDate||candidate?.date||candidate?.datePublished||'';
  const match=String(value).match(DATE_RE);
  return match?Number(match[1]):null;
}

export function yearFilterSummary(candidates,currentYear=new Date().getFullYear()){
  const years=[...new Set(candidates.map(yearOf).filter(Number.isInteger))].sort((a,b)=>a-b);
  const dated=candidates.filter(candidate=>Number.isInteger(yearOf(candidate))).length;
  const candidatesByYear=Object.fromEntries(years.map(year=>[year,candidates.filter(candidate=>yearOf(candidate)===year).length]));
  return {years,candidatesByYear,total:candidates.length,dated,undated:candidates.length-dated,currentYear};
}

export function filterCandidatesByYear(candidates,options={},currentYear=new Date().getFullYear()){
  const mode=options.mode||'all';
  const includeUndated=options.includeUndated!==false;
  const summary=yearFilterSummary(candidates,currentYear);
  let start=null,end=null;
  if(mode==='last-3'||mode==='last-5'||mode==='last-10'){
    const count=Number(mode.slice(5)); start=currentYear-count+1; end=currentYear;
  }else if(mode==='custom'){
    start=Number(options.startYear); end=Number(options.endYear);
    if(!Number.isInteger(start)||!Number.isInteger(end)||start>end)throw new Error('Custom year range must contain valid years in ascending order.');
  }else if(mode!=='all')throw new Error('Unknown year filter.');
  const selected=candidates.filter(candidate=>{
    const year=yearOf(candidate);
    if(year===null)return includeUndated;
    return start===null||year>=start&&year<=end;
  });
  return {candidates:selected,summary:{...summary,mode,startYear:start,endYear:end,selected:selected.length,excluded:candidates.length-selected.length,undatedIncluded:selected.filter(candidate=>yearOf(candidate)===null).length}};
}

export {yearOf};
