// Stripe Checkout URLs are opaque, short-lived capabilities. Keep them only
// server-side and reuse an unexpired session for the same owner to avoid
// duplicate checkout attempts on refresh or repeated clicks.
export async function reuseOrCreateCheckout({ownerKey, store, create, now = () => Date.now()} = {}) {
  if (!ownerKey || !store?.getCheckout || !store?.saveCheckout || !create) throw new Error('Invalid checkout request');
  const current = await store.getCheckout(ownerKey);
  if (current?.checkout_url && Date.parse(current.expires_at || '') > now()) return {...current, reused: true};
  const session = await create();
  if (!session?.id || !session?.url) throw new Error('Stripe Checkout did not return a session');
  const expiresAt = Number.isFinite(session.expires_at) ? new Date(session.expires_at * 1000).toISOString() : new Date(now() + 23 * 60 * 60 * 1000).toISOString();
  await store.saveCheckout(ownerKey, {sessionId: session.id, checkoutUrl: session.url, expiresAt});
  return {stripe_session_id: session.id, checkout_url: session.url, expires_at: expiresAt, reused: false};
}
