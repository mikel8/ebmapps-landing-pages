import {createDiscoveryLedger} from './discovery-ledger.mjs';
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs/promises';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {counts,idFor} from './engine.mjs';
import {epubBuffer} from './epub.mjs';
import {sourceFromInput} from './source.mjs';
import {discover,selectValidationSamples} from './discovery.mjs';
import {createJob,cancelJob,reconcile} from './crawler.mjs';
import {runLocalArticleCrawl} from './local-crawl.mjs';
import {mergeCachedArticles} from './cache.mjs';
import {createWorkflow,consumeWorkflow,peekWorkflow,projectJob,storeJob,getJob} from './workflow.mjs';
import {reviewCollection} from './review.mjs';
import {assembleBook,renderBookEpubAsync} from './book.mjs';
import {IMAGE_EXPORT_MODES,IMAGE_POLICY} from './image-optimize.mjs';
import {acquireImages,hydrateImageAssets} from './image-cache.mjs';
import {runtimePaths} from './runtime-paths.mjs';
import {createAnalytics} from './analytics.mjs';
import {createHostedRuntime,hostedArtifactName} from './hosted-runtime.mjs';
import {createHostedFetchGuard} from './hosted-fetch.mjs';
import {assessArticle} from './quality.mjs';
import {hostedInspectionProjection} from './discovery-report.mjs';
import {runHostedCrawl} from './hosted-crawl.mjs';
import {createHostedQueue} from './hosted-controls.mjs';
import {filterCandidatesByYear,yearFilterSummary} from './year-filter.mjs';
import {estimateEpubSize} from './estimate.mjs';
import {createHostedCheckout,handleBillingWebhook,supabaseBillingStoreFromEnv} from './billing-hosted.mjs';
import {exportAccess, foundingAccessEnabled, foundingOffer} from './billing-access.mjs';
import {reuseOrCreateCheckout} from './billing-checkout.mjs';
import {requestRecovery,verifyRecovery,createRecoveryLimiter,RECOVERY_MESSAGE} from './billing-recovery.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
const paths=runtimePaths({root}),data=paths.data,dbFile=paths.dbFile,artifacts=paths.artifacts,imageDir=paths.imageDir;
const hostedMode=process.env.BTB_RUNTIME==='hosted';
// Capture the platform fetch before the hosted crawler installs its GET-only
// SSRF guard. Telemetry has a fixed, application-owned destination and must
// retain POST semantics; crawler requests remain guarded below.
const analytics=createAnalytics({dataDir:data,fetchImpl:globalThis.fetch});
const hostedFetch=hostedMode?createHostedFetchGuard():null;
if(hostedFetch)hostedFetch.install();
const hosted=hostedMode?await createHostedRuntime({root:process.env.BTB_HOSTED_ROOT||path.join(data,'hosted-jobs')}):null;
if(hosted){await hosted.recoverInterrupted();await hosted.cleanup();setInterval(()=>void hosted.cleanup(),15*60*1000).unref()}
await fs.mkdir(artifacts,{recursive:true});
const BRIAN_EXPORT_SOURCE='https://brianbalfour.com/essays';
await fs.mkdir(data,{recursive:true});
await fs.mkdir(imageDir,{recursive:true});
async function readDb(){try{return JSON.parse(await fs.readFile(dbFile,'utf8'))}catch{return {items:[],jobs:{}}}}
let writeQueue=Promise.resolve();async function writeDb(x){const body=JSON.stringify(x,null,2),tmp=dbFile+'.tmp';writeQueue=writeQueue.then(async()=>{await fs.writeFile(tmp,body);await fs.rename(tmp,dbFile)});return writeQueue}
async function readBody(req){let s='';for await(const c of req)s+=c;return JSON.parse(s||'{}')}
async function readRawBody(req){let s='';for await(const c of req)s+=c;return s}
function send(res,status,value,type='application/json',headers={}){res.writeHead(status,{'content-type':type,...headers});res.end(type==='application/json'?JSON.stringify(value):value);return true}
function cookies(req){return Object.fromEntries(String(req.headers.cookie||'').split(';').map(x=>x.trim()).filter(Boolean).map(x=>{const i=x.indexOf('=');return i<0?[x,'']:[x.slice(0,i),decodeURIComponent(x.slice(i+1))]}))}
function validOwnerKey(value){return /^[A-Za-z0-9_-]{32,128}$/.test(value||'')}
function billingOwner(req,res,{create=false}={}){const existing=cookies(req).btb_billing_owner;if(validOwnerKey(existing))return existing;if(!create)return null;const owner=randomBytes(32).toString('base64url'),secure=hostedMode?'; Secure':'';res.setHeader('set-cookie',`btb_billing_owner=${owner}; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000${secure}`);return owner}

const HOSTED_QUEUE_LIMIT=Math.max(1,Number(process.env.BTB_HOSTED_QUEUE_LIMIT||8));
const HOSTED_PROCESSING_CONCURRENCY=Math.max(1,Number(process.env.BTB_HOSTED_PROCESSING_CONCURRENCY||1));
const HOSTED_EXPORT_CONCURRENCY=Math.max(1,Number(process.env.BTB_HOSTED_EXPORT_CONCURRENCY||1));
const HOSTED_DAILY_JOB_QUOTA=Math.max(1,Number(process.env.BTB_HOSTED_DAILY_JOB_QUOTA||20));
const hostedCrawls=new Map();let usageWrite=Promise.resolve();
const pendingCheckouts=new Map();
const recoveryLimiter=createRecoveryLimiter({});
const hostedQueue=createHostedQueue({capacity:HOSTED_QUEUE_LIMIT,concurrency:HOSTED_PROCESSING_CONCURRENCY,exportConcurrency:HOSTED_EXPORT_CONCURRENCY,onLimit:()=>void updateHostedUsage({resourceLimitTerminations:1})});
const hostedDisabled=()=>/^(1|true|yes|on)$/i.test(process.env.BTB_DISABLE_NEW_JOBS||'');
const usageFile=hosted?path.join(hosted.root,'usage.json'):null;
async function updateHostedUsage(change={}){if(!usageFile)return null;let result;usageWrite=usageWrite.then(async()=>{let value={day:new Date().toISOString().slice(0,10),jobsStarted:0,jobsCompleted:0,jobsFailed:0,resourceLimitTerminations:0,inputImageBytes:0,outputImageBytes:0,epubBytes:0,processingMs:0};try{value={...value,...JSON.parse(await fs.readFile(usageFile,'utf8'))}}catch{}const day=new Date().toISOString().slice(0,10);if(value.day!==day)value={...value,day,jobsStarted:0,jobsCompleted:0,jobsFailed:0,resourceLimitTerminations:0,inputImageBytes:0,outputImageBytes:0,epubBytes:0,processingMs:0};for(const [key,amount] of Object.entries(change))value[key]=(value[key]||0)+amount;const tmp=usageFile+'.tmp';await fs.writeFile(tmp,JSON.stringify(value,null,2));await fs.rename(tmp,usageFile);result=value});await usageWrite;return result}
async function admitHostedJob(){if(hostedDisabled())return {ok:false,status:503,error:'New processing is temporarily disabled.'};const usage=await updateHostedUsage();if(usage.jobsStarted>=HOSTED_DAILY_JOB_QUOTA)return {ok:false,status:429,error:'The hosted daily processing limit has been reached. Try again tomorrow.'};await updateHostedUsage({jobsStarted:1});return {ok:true}}
function canQueueHosted(){return hostedQueue.canAccept()}
function queueHosted(task,options){return hostedQueue.enqueue(task,options)}
function hostedProgress(crawl){const r=reconcile(crawl);return {total:r.total,processed:r.terminal,success:r.SUCCESS,reused:r.REUSED,previews:r.PUBLIC_PREVIEW,previewsReused:r.REUSED_PREVIEW,failed:r.failed,cancelled:r.CANCELLED}}
async function inspectHosted(id,{replay={}}={}){
  let job=await hosted.read(id);if(job.state==='CANCELLED')return;
  if(job.state!=='INSPECTING')await hosted.transition(id,'INSPECTING');
  const ledger=createDiscoveryLedger({replay});
  try{const result=await hostedFetch.withJob(job,()=>discover(job.source,{limits:job.limits,ledger}));job=await hosted.read(id);if(job.state==='CANCELLED')return;const discovery=result.diagnostics.discovery,completeness=discovery.completeness,inspection={...hostedInspectionProjection(result,job.limits),yearCoverage:yearFilterSummary(result.candidates)};await hosted.writeJson(id,'candidates.json',result.candidates);await hosted.writeJson(id,'discovery-ledger.json',result.diagnostics.discoveryLedger);await hosted.writeJson(id,'discovery-replay.json',ledger.replaySnapshot());await hosted.writeJson(id,'structural-profile.json',result.diagnostics.inspection.structuralProfile);await hosted.transition(id,'READY',{inspection});await analytics.capture('archive_inspection_completed',{surface:'web',discovery_strategy:result.strategy,candidate_count:result.candidates.length,archive_page_count:discovery.archivePagesInspected,completeness:completeness.status})}
  catch(error){await hosted.writeJson(id,'discovery-ledger.json',ledger.snapshot());job=await hosted.read(id);if(job.state!=='CANCELLED'){await hosted.transition(id,job.inspection?'READY':'FAILED',{error:{category:'INSPECTION_FAILED',message:job.inspection?'Archive inspection could not be completed. The previous result is still available.':'Archive inspection could not be completed.'}});await analytics.capture('archive_inspection_failed',{surface:'web',failure_category:'network_or_fetch'})}}
}
async function crawlHosted(id){
  let job=await hosted.read(id);if(job.state==='CANCELLED')return;
  const discoveredCandidates=await hosted.readJson(id,'candidates.json'),filtered=filterCandidatesByYear(discoveredCandidates,job.yearFilter||{}),candidates=filtered.candidates.slice(0,job.limits.maxCrawledArticles),articles=await hosted.readJson(id,'articles.json'),assets=await hosted.readJson(id,'assets.json');
  let crawl;
  try{const result=await runHostedCrawl({job,candidates,articles,assets,imageDir:path.join(hosted.jobDir(id),'images'),fetchGuard:hostedFetch,imageLimits:{maxImages:job.limits.maxImages,maxBytes:job.limits.maxImageBytes,concurrency:4,timeoutMs:15_000},persist:async state=>{crawl=state.crawl;hostedCrawls.set(id,crawl);await hosted.writeJson(id,'articles.json',articles);await hosted.writeJson(id,'assets.json',assets);await hosted.writeJson(id,'outcomes.json',state.failures||[]);const current=await hosted.read(id);if(current.state==='CANCELLED')cancelJob(crawl);else await hosted.patch(id,{progress:hostedProgress(crawl),resources:{...state.budget,imageStats:state.imageStats}})}});crawl=result.crawl;hostedCrawls.set(id,crawl);await hosted.writeJson(id,'outcomes.json',result.failures);job=await hosted.read(id);if(job.state!=='CANCELLED'){const p=hostedProgress(crawl);await hosted.transition(id,'REVIEW',{progress:p,resources:{...result.budget,imageStats:result.imageStats},review:{available:p.success+p.reused+p.previews+p.previewsReused,publicPreviews:p.previews+p.previewsReused,excluded:p.failed,failures:result.failures}});await analytics.capture('crawl_completed',{surface:'web',article_count:p.total,success_count:p.success,reused_count:p.reused,failure_count:p.failed})}}
  catch(error){job=await hosted.read(id);if(job.state!=='CANCELLED'){await hosted.transition(id,'FAILED',{error:{category:'CRAWL_FAILED',message:'Archive crawl could not be completed.'},progress:crawl?hostedProgress(crawl):job.progress});await analytics.capture('crawl_failed',{surface:'web',failure_category:'crawl_error'})}}
  finally{hostedCrawls.delete(id)}
}
function safeReview(result,selection=[]){return {...result,source:undefined,articles:result.articles.map(a=>({...a,canonicalUrl:undefined,included:selection.includes(a.id)}))}}
async function exportHosted(id){let job;try{job=await hosted.read(id);const items=await hosted.readJson(id,'articles.json'),selection=await hosted.readJson(id,'selection.json'),assets=await hosted.readJson(id,'assets.json'),localAssets=await hydrateImageAssets(assets,path.join(hosted.jobDir(id),'images')),book=assembleBook(job.source,selection,items,{imageAssets:localAssets,removePromotionalFooters:selection.removePromotionalFooters!==false}),started=Date.now(),rendered=await renderBookEpubAsync(book,{imageMode:selection.imageMode||IMAGE_EXPORT_MODES.OPTIMIZED}),buffer=rendered.buffer,name=hostedArtifactName(id);await hosted.writeArtifact(id,name,buffer);if(job.billing?.firstFreeClaimId)await supabaseBillingStoreFromEnv().finalizeFirstExport(job.billing.ownerKey,job.billing.firstFreeClaimId);await updateHostedUsage({jobsCompleted:1,inputImageBytes:rendered.stats.originalBytes,outputImageBytes:rendered.stats.outputBytes,epubBytes:buffer.length,processingMs:Date.now()-started,resourceLimitTerminations:rendered.stats.resourceLimited});const skipped=rendered.stats.explainedImageReferences;await hosted.transition(id,'COMPLETE',{export:{chapters:book.chapters.length,words:book.wordCount,publicPreviews:book.publicPreviews,imagesPackaged:rendered.stats.packaged,imagesSkipped:skipped,imageReferences:rendered.stats.meaningfulImageReferences,imageReferencesAvailable:rendered.stats.availableImageReferences,imageReferencesPackaged:rendered.stats.packagedImageReferences,imageReferencesExplained:rendered.stats.explainedImageReferences,optimizedImages:rendered.stats.optimized,gifsOmitted:rendered.stats.gifsOmitted,imageFailures:rendered.stats.failed,imageMode:rendered.stats.mode,inputImageBytes:rendered.stats.originalBytes,outputImageBytes:rendered.stats.outputBytes,duplicateBytesSaved:rendered.stats.duplicateBytesSaved,bytes:buffer.length,durationMs:Date.now()-started,warnings:buffer.length>IMAGE_POLICY.maxOutputBytes?['EXPORT_EXCEEDS_SUPPORTED_SIZE']:buffer.length>IMAGE_POLICY.warningBytes?['EXPORT_APPROACHING_SIZE_LIMIT']:[]}});await analytics.capture('epub_export_completed',{surface:'web',selected_article_count:book.chapters.length,word_count:book.wordCount,packaged_image_count:rendered.stats.packaged,skipped_image_count:skipped,artifact_bytes:buffer.length})}catch(error){if(job?.billing?.firstFreeClaimId){try{await supabaseBillingStoreFromEnv().releaseFirstExport(job.billing.ownerKey,job.billing.firstFreeClaimId)}catch{}}await updateHostedUsage({jobsFailed:1});console.error('[hosted:export:error]',id,error?.name||'Error',error?.message||'Unknown export failure');const current=await hosted.read(id);if(current.state!=='CANCELLED')await hosted.transition(id,'FAILED',{error:{category:'EXPORT_FAILED',message:'The book could not be prepared.'}});await analytics.capture('epub_export_failed',{surface:'web',failure_category:'export_error'})}}
async function authorizeHostedExport(req,res,job){
  if(!foundingAccessEnabled())return {allowed:true,access:{allowed:true,kind:'feature_disabled'}};
  if(!billingEnabledForAccess())throw Error('Billing is not configured');
  const ownerKey=billingOwner(req,res,{create:true}),store=supabaseBillingStoreFromEnv(),entitlement=await store.getEntitlement(ownerKey),paid=exportAccess({enabled:true,entitlement});
  if(paid.allowed)return {allowed:true,access:paid,billing:{ownerKey}};
  const claimId=randomBytes(24).toString('base64url'),claimed=await store.claimFirstExport(ownerKey,claimId),access=exportAccess({enabled:true,entitlement,firstExportClaimed:claimed});
  return access.allowed?{allowed:true,access,billing:{ownerKey,firstFreeClaimId:claimId}}:{allowed:false,access};
}
function billingEnabledForAccess(){return Boolean(process.env.BLOGTOBOOK_SUPABASE_URL&&process.env.BLOGTOBOOK_SUPABASE_SERVICE_ROLE_KEY)}
async function hostedCheckoutFor(ownerKey,analyticsId,trafficClass){
  if(pendingCheckouts.has(ownerKey))return pendingCheckouts.get(ownerKey);
  const task=reuseOrCreateCheckout({ownerKey,store:supabaseBillingStoreFromEnv(),create:()=>createHostedCheckout({ownerKey,analyticsId,trafficClass})});
  pendingCheckouts.set(ownerKey,task);
  try{return await task}finally{pendingCheckouts.delete(ownerKey)}
}
function sendRecoveryEmail({email,code,recoveryId}){return new Promise((resolve,reject)=>{if(!process.env.RESEND_API_KEY||!process.env.BLOGTOBOOK_RESEND_FROM)return reject(new Error('Recovery email is not configured'));const body=JSON.stringify({from:process.env.BLOGTOBOOK_RESEND_FROM,to:[email],subject:'Your BlogToBook verification code',text:`Your BlogToBook verification code is:\n\n${code}\n\nRecovery ID: ${recoveryId}\n\nIt expires in 15 minutes. If you did not request this, ignore this email.`});const req=https.request('https://api.resend.com/emails',{method:'POST',headers:{authorization:`Bearer ${process.env.RESEND_API_KEY}`,'content-type':'application/json','content-length':Buffer.byteLength(body)}},res=>{res.resume();res.on('end',()=>res.statusCode>=200&&res.statusCode<300?resolve():reject(new Error('Recovery email delivery failed')))});req.on('error',reject);req.end(body)})}
async function requestHostedExport(req,res,id){
  if(hostedDisabled())return send(res,503,{error:'New processing is temporarily disabled.'});
  let job=await hosted.read(id);
  if(job.state!=='REVIEW')return send(res,409,{error:'This job is not ready to export'});
  if(!canQueueHosted())return send(res,429,{error:'The hosted processing queue is currently full.'});
  const input=await readBody(req),access=await authorizeHostedExport(req,res,job);
  if(!access.allowed)return send(res,402,{error:'Founding Access is required for additional exports.',code:'FOUNDING_ACCESS_REQUIRED',offer:access.access.offer});
  if(Array.isArray(input.articleIds)){
    const items=await hosted.readJson(job.id,'articles.json'),valid=new Set(items.filter(x=>assessArticle(x).eligible).map(x=>x.id)),ids=[...new Set(input.articleIds)],imageMode=Object.values(IMAGE_EXPORT_MODES).includes(input.imageMode)?input.imageMode:IMAGE_EXPORT_MODES.OPTIMIZED;
    if(!ids.length||ids.some(articleId=>!valid.has(articleId)))return send(res,400,{error:'Select valid articles before exporting.'});
    await hosted.writeJson(job.id,'selection.json',{articleIds:ids,chronology:input.chronology||'UNKNOWN_CHRONOLOGY',imageMode,removePromotionalFooters:input.removePromotionalFooters!==false});
  }else if(!(await hosted.readJson(job.id,'selection.json').catch(()=>null)))return send(res,400,{error:'Select at least one article.'});
  if(access.billing)job=await hosted.patch(job.id,{billing:access.billing});
  await hosted.transition(job.id,'EXPORTING');
  await analytics.capture('epub_export_started',{surface:'web'});
  if(!queueHosted(()=>exportHosted(job.id),{kind:'export'})){
    if(access.billing?.firstFreeClaimId)await supabaseBillingStoreFromEnv().releaseFirstExport(access.billing.ownerKey,access.billing.firstFreeClaimId);
    await hosted.transition(job.id,'FAILED',{error:{category:'QUEUE_FULL',message:'The hosted processing queue is currently full.'}});
    return send(res,429,{error:'The hosted processing queue is currently full.'});
  }
  return send(res,202,hosted.status(await hosted.read(job.id)));
}
async function hostedApi(req,res){
  const pathname=new URL(req.url,'http://localhost').pathname,match=pathname.match(/^\/api\/jobs\/([A-Za-z0-9_-]+)(?:\/(crawl|cancel|review|selection|export|download|estimate|retry))?$/);
  try{
    if(pathname==='/api/billing/status'&&req.method==='GET'){
      const enabled=foundingAccessEnabled();
      if(!enabled)return send(res,200,{enforced:false});
      const ownerKey=billingOwner(req,res,{create:true}),entitlement=await supabaseBillingStoreFromEnv().getEntitlement(ownerKey);
      return send(res,200,{enforced:true,entitlement:entitlement?.status==='active'?{productKey:entitlement.product_key,status:entitlement.status}:null,offer:foundingOffer()});
    }
    if(pathname==='/api/billing/checkout'&&req.method==='POST'){
      if(!foundingAccessEnabled())return send(res,404,{error:'Billing is not active.'});
      const input=await readBody(req),ownerKey=billingOwner(req,res,{create:true}),session=await hostedCheckoutFor(ownerKey,input.analytics_id,input.traffic_class);
      return send(res,200,{id:session.stripe_session_id,url:session.checkout_url,reused:session.reused});
    }
    if(pathname==='/api/billing/entitlement'&&req.method==='POST'){
      const ownerKey=billingOwner(req,res);if(!ownerKey)return send(res,200,{entitlement:null});
      if(!billingEnabledForAccess())return send(res,503,{error:'Billing is not configured'});
      const entitlement=await supabaseBillingStoreFromEnv().getEntitlement(ownerKey);
      return send(res,200,{entitlement:entitlement?.status==='active'?{productKey:entitlement.product_key,status:entitlement.status}:null});
    }
    if(pathname==='/api/billing/recovery/request'&&req.method==='POST'){
      const input=await readBody(req);let result={accepted:true,message:RECOVERY_MESSAGE};
      if(billingEnabledForAccess()&&process.env.BLOGTOBOOK_RECOVERY_HASH_SECRET){try{result=await requestRecovery({email:input.email,store:supabaseBillingStoreFromEnv(),sendCode:sendRecoveryEmail,hashSecret:process.env.BLOGTOBOOK_RECOVERY_HASH_SECRET,limiter:recoveryLimiter})}catch(error){console.error('[billing:recovery:delivery]',error?.name||'Error')}}
      return send(res,202,{accepted:true,message:result.message});
    }
    if(pathname==='/api/billing/recovery/verify'&&req.method==='POST'){
      const ownerKey=billingOwner(req,res,{create:true}),input=await readBody(req),result=await verifyRecovery({recoveryId:input.recoveryId,code:input.code,store:supabaseBillingStoreFromEnv(),ownerKey,hashSecret:process.env.BLOGTOBOOK_RECOVERY_HASH_SECRET});
      return send(res,result.restored?200:400,result.restored?{restored:true}:{restored:false,error:'That verification code is invalid or expired.'});
    }
    if(match&&match[2]==='export'&&req.method==='POST')return requestHostedExport(req,res,match[1]);
    if(pathname==='/api/billing/webhook'&&req.method==='POST'){const payload=await readRawBody(req);const result=await handleBillingWebhook({payload,signature:req.headers['stripe-signature']});const event=JSON.parse(payload),obj=event.data?.object||{},m=obj.metadata||{};if(result.processed&&['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type)&&obj.payment_status==='paid'&&m.product==='blogtobook_founding_access'&&m.traffic_class==='external'&&/^[0-9a-f-]{36}$/i.test(m.analytics_id||'')){await analytics.captureFunnelPayment(m.analytics_id,event.id)}return send(res,200,result)}
    if(pathname==='/api/jobs'&&req.method==='POST'){const admission=await admitHostedJob();if(!admission.ok)return send(res,admission.status,{error:admission.error});const input=await readBody(req),source=sourceFromInput(input.archiveUrl);hostedFetch.validateUrl(source.archiveUrl);let job=await hosted.create({source});const pages=Number(input.maxArchivePages);if([10,50,100].includes(pages))job=await hosted.patch(job.id,{limits:{...job.limits,maxArchivePages:pages}});if(!queueHosted(()=>inspectHosted(job.id))){await hosted.transition(job.id,'FAILED',{error:{category:'QUEUE_FULL',message:'The hosted processing queue is currently full.'}});return send(res,429,{error:'The hosted processing queue is currently full.'})}await analytics.capture('source_submitted',{surface:'web'});send(res,202,{jobId:job.id,state:job.state});return true}
    if(match&&req.method==='GET'&&!match[2]){const job=await hosted.read(match[1]);send(res,200,hosted.status(job));return true}
    if(match&&match[2]==='retry'&&req.method==='POST'){let job=await hosted.read(match[1]);if(job.state!=='READY')return send(res,409,{error:'Inspection is not ready to retry'});if(!canQueueHosted())return send(res,429,{error:'The hosted processing queue is currently full.'});const input=await readBody(req),pages=Number(input.maxArchivePages),replay=await hosted.readJson(job.id,'discovery-replay.json').catch(()=>({}));if([10,50,100].includes(pages))job=await hosted.patch(job.id,{limits:{...job.limits,maxArchivePages:pages}});hostedFetch.renewDeadline(job.id,job.limits.jobDeadlineMs);await hosted.transition(job.id,'INSPECTING',{error:null});if(!queueHosted(()=>inspectHosted(job.id,{replay}))){await hosted.transition(job.id,'READY');return send(res,429,{error:'The hosted processing queue is currently full.'})}return send(res,202,{jobId:job.id,state:'INSPECTING'})}
    if(match&&match[2]==='estimate'&&req.method==='POST'){const job=await hosted.read(match[1]),candidates=await hosted.readJson(job.id,'candidates.json'),input=await readBody(req),filtered=filterCandidatesByYear(candidates,input.yearFilter||job.yearFilter||{}),db=await readDb(),estimate=estimateEpubSize(filtered.candidates,{mode:input.imageMode||'optimized',cachedItems:db.items||[],maxSamples:5});return send(res,200,{...estimate,yearFilter:filtered.summary})}
    if(match&&match[2]==='crawl'&&req.method==='POST'){if(hostedDisabled())return send(res,503,{error:'New processing is temporarily disabled.'});let job=await hosted.read(match[1]);if(job.state!=='READY')return send(res,409,{error:'This job is not ready to crawl'});if(!canQueueHosted())return send(res,429,{error:'The hosted processing queue is currently full.'});const input=await readBody(req),yearFilter=input.yearFilter||{};job=await hosted.patch(job.id,{yearFilter});job=await hosted.transition(job.id,'CRAWLING');if(!queueHosted(()=>crawlHosted(job.id))){await hosted.transition(job.id,'FAILED',{error:{category:'QUEUE_FULL',message:'The hosted processing queue is currently full.'}});return send(res,429,{error:'The hosted processing queue is currently full.'})}send(res,202,hosted.status(job));return true}
    if(match&&match[2]==='review'&&req.method==='GET'){const job=await hosted.read(match[1]);if(job.state!=='REVIEW'&&job.state!=='COMPLETE')return send(res,409,{error:'Review is not available yet'});const items=await hosted.readJson(job.id,'articles.json'),failures=await hosted.readJson(job.id,'outcomes.json').catch(()=>[]),selection=job.state==='COMPLETE'?(await hosted.readJson(job.id,'selection.json')).articleIds:[],result=reviewCollection(job.source,items,{failures});await analytics.capture('review_opened',{surface:'web',article_count:result.articles.length});return send(res,200,safeReview(result,selection))}
    if(match&&match[2]==='selection'&&req.method==='POST'){const job=await hosted.read(match[1]);if(job.state!=='REVIEW')return send(res,409,{error:'Selection is not available in this state'});const input=await readBody(req),items=await hosted.readJson(job.id,'articles.json'),eligible=items.filter(x=>assessArticle(x).eligible),valid=new Set(eligible.map(x=>x.id)),ids=Array.isArray(input.articleIds)?[...new Set(input.articleIds)]:[];if(!ids.length)return send(res,400,{error:'Select at least one article.'});if(ids.some(id=>!valid.has(id)))return send(res,400,{error:'One or more selected articles are unavailable.'});await hosted.writeJson(job.id,'selection.json',{articleIds:ids,chronology:input.chronology||'UNKNOWN_CHRONOLOGY'});await hosted.patch(job.id,{review:{available:eligible.length,selected:ids.length}});await analytics.capture('review_selection_changed',{surface:'web',selected_article_count:ids.length});return send(res,200,{selected:ids.length,total:eligible.length})}
    if(match&&match[2]==='export'&&req.method==='POST'){if(hostedDisabled())return send(res,503,{error:'New processing is temporarily disabled.'});const job=await hosted.read(match[1]);if(job.state!=='REVIEW')return send(res,409,{error:'This job is not ready to export'});if(!canQueueHosted())return send(res,429,{error:'The hosted processing queue is currently full.'});const input=await readBody(req);if(Array.isArray(input.articleIds)){const items=await hosted.readJson(job.id,'articles.json'),valid=new Set(items.filter(x=>assessArticle(x).eligible).map(x=>x.id)),ids=[...new Set(input.articleIds)],imageMode=Object.values(IMAGE_EXPORT_MODES).includes(input.imageMode)?input.imageMode:IMAGE_EXPORT_MODES.OPTIMIZED;if(!ids.length||ids.some(id=>!valid.has(id)))return send(res,400,{error:'Select valid articles before exporting.'});await hosted.writeJson(job.id,'selection.json',{articleIds:ids,chronology:input.chronology||'UNKNOWN_CHRONOLOGY',imageMode,removePromotionalFooters:input.removePromotionalFooters!==false});}else if(!(await hosted.readJson(job.id,'selection.json').catch(()=>null)))return send(res,400,{error:'Select at least one article.'});await hosted.transition(job.id,'EXPORTING');await analytics.capture('epub_export_started',{surface:'web'});if(!queueHosted(()=>exportHosted(job.id),{kind:'export'})){await hosted.transition(job.id,'FAILED',{error:{category:'QUEUE_FULL',message:'The hosted processing queue is currently full.'}});return send(res,429,{error:'The hosted processing queue is currently full.'})}return send(res,202,hosted.status(await hosted.read(job.id)))}
    if(match&&match[2]==='download'&&req.method==='GET'){const job=await hosted.read(match[1]);if(!job.artifact)return send(res,404,{error:'This download has expired.'});const bytes=await hosted.readArtifact(job.id,job.artifact.name);res.writeHead(200,{'content-type':'application/epub+zip','content-disposition':`attachment; filename="${job.artifact.name}"`});res.end(bytes);return true}
    if(match&&match[2]==='cancel'&&req.method==='POST'){const job=await hosted.requestCancel(match[1]);const crawl=hostedCrawls.get(job.id);if(crawl)cancelJob(crawl);send(res,200,hosted.status(job));return true}
    if(pathname.startsWith('/api/')){send(res,404,{error:'Hosted API endpoint not found'});return true}
  }catch(error){const status=/Job not found|Illegal hosted job transition/.test(error.message)?404:400;send(res,status,{error:error.message});return true}
  return false
}

async function discoverBrian(source){
  const archive=new URL(source.archiveUrl);
  let page=source.archiveUrl,pages=0,all=[],seen=new Set(),lastHtml='';
  while(page&&pages<100&&!seen.has(page)){
    seen.add(page);
    const response=await fetch(page,{headers:{'user-agent':'BlogToBook Brian vertical slice/0.3'}});
    lastHtml=await response.text();
    if(!response.ok)throw Error(`Brian returned HTTP ${response.status}`);
    all.push(...segmentInline(lastHtml,page)); pages++;
    const match=lastHtml.match(/<a[^>]+class=["'][^"']*older-posts[^"']*["'][^>]+href=["']([^"']+)["']/i)||lastHtml.match(/<a[^>]+href=["']([^"']+)["'][^>]*>\s*Older Posts/i);
    if(!match)break;
    try{const next=new URL(match[1],page);const offset=next.searchParams.get('offset');if(next.origin!==archive.origin||next.pathname!==archive.pathname||!/^\d{1,16}$/.test(offset||''))break;page=next.href}catch{break}
  }
  const unique=[];const used=new Set();
  for(const item of all){const key=item.url||item.title;if(!used.has(key)){used.add(key);unique.push(item)}}
  unique.sort((a,b)=>(Date.parse(a.date)||Infinity)-(Date.parse(b.date)||Infinity));
  const pre=inspect(lastHtml,source.archiveUrl);pre.type='inline multi-article archive';pre.pagination={pagesFollowed:pages,olderPostsFound:pages>1};
  const samples=[unique[0],unique[Math.floor(unique.length/2)],unique.at(-1)].filter(Boolean).map(x=>({...x,bodySample:x.blocks.filter(b=>b.text).map(b=>b.text).join(' ').slice(0,280)}));
  return {preflight:pre,items:unique,samples};
}

async function startJob(workflow){
  const db=await readDb();const id=idFor(Date.now()+''),job=storeJob({...createJob(workflow.source,workflow.candidates,id),url:workflow.source.archiveUrl,preflight:workflow.diagnostics,startedAt:new Date().toISOString()});
  runLocalArticleCrawl(job,{cache:db.items,persist:async items=>{const now=await readDb();now.items=mergeCachedArticles(now.items||[],items);await writeDb(now)}}).then(()=>analytics.capture(job.state==='COMPLETED'?'crawl_completed':job.state==='CANCELLED'?'crawl_cancelled':'crawl_failed',{article_count:job.total,success_count:job.outcomes.SUCCESS,reused_count:job.outcomes.REUSED,failure_count:job.outcomes.failed})).catch(error=>{job.state='FAILED';job.error=error.message;analytics.capture('crawl_failed',{failure_category:'runner_error'})});
  return {jobId:id,total:workflow.candidates.length};
}

const server=http.createServer(async(req,res)=>{try{
  if(hostedMode&&await hostedApi(req,res))return;
  if(req.url==='/api/preflight'&&req.method==='POST'){const input=await readBody(req);await analytics.capture('source_submitted');const previous=input.workflowId?peekWorkflow(input.workflowId):null,source=previous?previous.source:sourceFromInput(input.archiveUrl),pages=Number(input.maxArchivePages),ledger=createDiscoveryLedger({replay:previous?.replay||{}});await analytics.capture('archive_inspection_started');let x;try{x=await discover(source,{ledger,limits:{maxArchivePages:[10,50,100].includes(pages)?pages:50}})}catch(error){await analytics.capture('archive_inspection_failed',{failure_category:'network_or_fetch'});throw error}const workflow=createWorkflow(source,x.candidates,x.diagnostics),samples=selectValidationSamples(x),selection=x.diagnostics.strategy||{primary:x.strategy,confidence:0,evidence:[]},metadata=x.diagnostics.metadata||{},discovery=x.diagnostics.discovery,completeness=discovery.completeness,pagesFollowed=discovery.archivePagesInspected,yearCoverage=yearFilterSummary(x.candidates);workflow.replay=ledger.replaySnapshot();await analytics.capture('archive_inspection_completed',{discovery_strategy:selection.primary,candidate_count:x.candidates.length,dated_candidate_count:metadata.dated||0,archive_page_count:pagesFollowed,completeness:completeness.status});return send(res,200,{workflowId:workflow.id,url:source.archiveUrl,archiveType:x.diagnostics.type||selection.primary,evidence:{...(x.diagnostics.evidence||{}),pagesFollowed,terminationReason:discovery.terminationReason,limitsReached:discovery.limitsReached,continuationRequestsFailed:discovery.continuationRequestsFailed,continuationStrategiesAttempted:discovery.continuationStrategiesAttempted,completeness},metadata,strategy:selection,discovered:x.candidates.length,yearCoverage,sampleLabels:samples.labels,samples:[samples.oldest,samples.middle,samples.newest].filter(Boolean).map(a=>({...a,bodySample:a.previewBlocks.filter(b=>b.text).map(b=>b.text).join(' ').slice(0,280)}))})}
  if(req.url==='/api/estimate'&&req.method==='POST'){const input=await readBody(req),workflow=peekWorkflow(input.workflowId),db=await readDb(),filtered=filterCandidatesByYear(workflow.candidates,input.yearFilter||{}),estimate=estimateEpubSize(filtered.candidates,{mode:input.imageMode||'optimized',cachedItems:db.items||[],maxSamples:5});return send(res,200,{...estimate,yearFilter:filtered.summary})}
  if(req.url==='/api/crawl'&&req.method==='POST'){const input=await readBody(req);console.log('[api:crawl]',input.workflowId);if(input.confirm!==true||!input.workflowId)return send(res,400,{error:'Inspect the archive again before confirming'});const workflow=consumeWorkflow(input.workflowId),filtered=filterCandidatesByYear(workflow.candidates,input.yearFilter);workflow.candidates=filtered.candidates;workflow.yearFilter=filtered.summary;await analytics.capture('crawl_started',{article_count:workflow.candidates.length});console.log('[api:workflow]',workflow.id,workflow.candidates.length);const started=await startJob(workflow);console.log('[api:job]',started.jobId,started.total);return send(res,200,{...started,yearFilter:filtered.summary})}
  if(req.url.startsWith('/api/job/')){const id=req.url.split('/').pop(),job=getJob(id),p=job&&projectJob(job);console.log('[api:job:get]',id,!!job,p?.state,p?.processed,p?.outcomes?.REUSED,p?.remaining);return job?send(res,200,p):send(res,404,{error:'Job not found'})}
  if(req.url==='/api/cancel'&&req.method==='POST'){const input=await readBody(req),job=getJob(input.jobId);if(job){cancelJob(job);await analytics.capture('crawl_cancelled',{article_count:job.total})}return send(res,200,{ok:true})}
  if(req.url==='/api/cache'){const db=await readDb();return send(res,200,{items:db.items,counts:counts(db.items)})}
  if(req.url==='/api/analytics'&&req.method==='POST'){const input=await readBody(req);await analytics.capture(input.event,input.properties&&typeof input.properties==='object'?input.properties:{});return send(res,204,'', 'text/plain')}
  if(new URL(req.url,'http://localhost').pathname==='/api/review'){const u=new URL(req.url,'http://localhost'),source=sourceFromInput(u.searchParams.get('archiveUrl')||''),db=await readDb(),result=reviewCollection(source,db.items);await analytics.capture('review_opened',{article_count:result.articles.length});return send(res,200,result)}
  if(req.url==='/api/images/backfill'&&req.method==='POST'){const input=await readBody(req),source=sourceFromInput(input.archiveUrl),db=await readDb(),items=db.items.filter(x=>x.source?.sourceId===source.sourceId&&assessArticle(x).eligible),result=await acquireImages(items,{assets:db.imageAssets||[],imageDir});db.imageAssets=result.assets;await writeDb(db);return send(res,200,result.stats)}
  if(req.url==='/api/export'&&req.method==='POST'){const input=await readBody(req),source=sourceFromInput(input.archiveUrl),db=await readDb(),imageMode=Object.values(IMAGE_EXPORT_MODES).includes(input.imageMode)?input.imageMode:IMAGE_EXPORT_MODES.OPTIMIZED,selection={articleIds:Array.isArray(input.articleIds)?[...new Set(input.articleIds)]:[],chronology:input.chronology||'UNKNOWN_CHRONOLOGY',imageMode,removePromotionalFooters:input.removePromotionalFooters!==false};await analytics.capture('epub_export_started',{selected_article_count:selection.articleIds.length});try{const assets=await hydrateImageAssets(db.imageAssets||[],imageDir),book=assembleBook(source,selection,db.items,{imageAssets:assets,removePromotionalFooters:selection.removePromotionalFooters!==false}),started=Date.now(),rendered=await renderBookEpubAsync(book,{imageMode}),buffer=rendered.buffer,name=`book-${idFor(Date.now()+'')}.epub`;await fs.writeFile(path.join(artifacts,name),buffer);const skipped=rendered.stats.explainedImageReferences,warnings=buffer.length>IMAGE_POLICY.maxOutputBytes?['EXPORT_EXCEEDS_SUPPORTED_SIZE']:buffer.length>IMAGE_POLICY.warningBytes?['EXPORT_APPROACHING_SIZE_LIMIT']:[];await analytics.capture('epub_export_completed',{selected_article_count:book.chapters.length,word_count:book.wordCount,packaged_image_count:rendered.stats.packaged,skipped_image_count:skipped,artifact_bytes:buffer.length,chronology_status:selection.chronology});return send(res,200,{filename:name,download:`/api/download/${name}`,chapters:book.chapters.length,words:book.wordCount,publicPreviews:book.publicPreviews,imagesPackaged:rendered.stats.packaged,imagesSkipped:skipped,imageReferences:rendered.stats.meaningfulImageReferences,imageReferencesAvailable:rendered.stats.availableImageReferences,imageReferencesPackaged:rendered.stats.packagedImageReferences,imageReferencesExplained:rendered.stats.explainedImageReferences,optimizedImages:rendered.stats.optimized,gifsOmitted:rendered.stats.gifsOmitted,imageFailures:rendered.stats.failed,inputImageBytes:rendered.stats.originalBytes,outputImageBytes:rendered.stats.outputBytes,duplicateBytesSaved:rendered.stats.duplicateBytesSaved,imageMode,fileSize:buffer.length,footerPatternsDetected:book.footerCleanup.patternsDetected,promotionalFootersRemoved:book.footerCleanup.articleFootersRemoved,footerArticlesUnchanged:book.footerCleanup.articlesUnchanged,durationMs:Date.now()-started,warnings})}catch(error){await analytics.capture('epub_export_failed',{failure_category:'export_error'});throw error}}
  if(req.url.startsWith('/api/download/')){const name=path.basename(req.url.slice('/api/download/'.length));if(!/^[a-z0-9-]+\.epub$/.test(name))return send(res,400,{error:'Invalid artifact'});res.writeHead(200,{'content-type':'application/epub+zip','content-disposition':`attachment; filename="${name}"`});return res.end(await fs.readFile(path.join(artifacts,name)))}
  if(req.url==='/api/export/brian.epub'){const db=await readDb(),items=db.items.filter(x=>assessArticle(x).eligible&&(x.source===BRIAN_EXPORT_SOURCE||x.source?.archiveUrl===BRIAN_EXPORT_SOURCE)).sort((a,b)=>(Date.parse(a.date)||Infinity)-(Date.parse(b.date)||Infinity)),assets={};for(const item of items)for(const block of item.blocks||[]){if(block.type!=='image'||assets[block.src])continue;try{const r=await fetch(block.src);if(r.ok){const bytes=Buffer.from(await r.arrayBuffer()),ext=(block.src.match(/\.(png|jpe?g|gif|webp)(?:\?|$)/i)?.[1]||'jpg').toLowerCase(),name=`images/image-${Object.keys(assets).length+1}.${ext}`;assets[block.src]={path:name,bytes,mime:ext==='png'?'image/png':ext==='gif'?'image/gif':ext==='webp'?'image/webp':'image/jpeg'}}}catch{}}res.writeHead(200,{'content-type':'application/epub+zip','content-disposition':'attachment; filename="brian-balfour-essays.epub"'});return res.end(epubBuffer(items,assets))}
  const requestPath=new URL(req.url,'http://localhost').pathname;
  const file=path.join(root,'public',requestPath==='/'?'index.html':requestPath);let body=await fs.readFile(file);if(hostedMode&&requestPath==='/')body=Buffer.from(body.toString().replace('window.BTB_HOSTED=false','window.BTB_HOSTED=true'));return send(res,200,body,file.endsWith('.js')?'text/javascript':'text/html');
}catch(error){send(res,500,{error:error.message})}});
server.listen(process.env.PORT||4173,hostedMode?(process.env.BTB_HOSTED_BIND||'127.0.0.1'):'127.0.0.1',()=>{analytics.capture('app_started');console.log('BlogToBook Brian prototype http://localhost:'+(process.env.PORT||4173))});
