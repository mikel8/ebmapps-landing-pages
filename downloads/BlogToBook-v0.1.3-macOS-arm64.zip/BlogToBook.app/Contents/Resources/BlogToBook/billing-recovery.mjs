import crypto from 'node:crypto';

export const RECOVERY_MESSAGE = 'If a matching purchase exists, we will email a verification code shortly.';
export function normalizePurchaseEmail(value) {
  const email = String(value || '').trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : null;
}
export function hashPurchaseEmail(email, secret) {
  const normalized = normalizePurchaseEmail(email);
  if (!normalized || !secret) return null;
  return crypto.createHmac('sha256', String(secret)).update(normalized).digest('hex');
}
export function hashRecoveryCode(code, secret) {
  if (!code || !secret) return null;
  return crypto.createHmac('sha256', String(secret)).update(String(code)).digest('hex');
}
export function createRecoveryCode() { return crypto.randomBytes(24).toString('base64url'); }
export function recoveryExpiry(now = Date.now(), ttlMs = 15 * 60 * 1000) { return new Date(now + ttlMs).toISOString(); }
export function createRecoveryLimiter({windowMs = 15 * 60 * 1000, max = 3, now = () => Date.now()} = {}) {
  const entries = new Map();
  return key => {
    const t = now(), prior = entries.get(key);
    if (!prior || t - prior.started >= windowMs) { entries.set(key, {started: t, count: 1}); return true; }
    if (prior.count >= max) return false;
    prior.count += 1; return true;
  };
}
export async function requestRecovery({email, store, sendCode, hashSecret, now = Date.now(), limiter = () => true}) {
  const normalized = normalizePurchaseEmail(email), emailHash = hashPurchaseEmail(normalized, hashSecret);
  if (!limiter(emailHash || 'invalid')) return {accepted: true, message: RECOVERY_MESSAGE, rateLimited: true};
  if (!emailHash || !store?.findActiveByEmailHash) return {accepted: true, message: RECOVERY_MESSAGE};
  const entitlement = await store.findActiveByEmailHash(emailHash);
  if (!entitlement) return {accepted: true, message: RECOVERY_MESSAGE};
  const code = createRecoveryCode(), recoveryId = crypto.randomUUID();
  await store.issueRecovery({recoveryId, emailHash, tokenHash: hashRecoveryCode(code, hashSecret), expiresAt: recoveryExpiry(now)});
  await sendCode({email: normalized, code, recoveryId});
  return {accepted: true, message: RECOVERY_MESSAGE, sent: true};
}
export async function verifyRecovery({recoveryId, code, store, ownerKey, hashSecret}) {
  if (!recoveryId || !code || !ownerKey || !store?.consumeRecovery) return {restored: false};
  const record = await store.consumeRecovery({recoveryId, tokenHash: hashRecoveryCode(code, hashSecret)});
  if (!record || record.product_key !== 'blogtobook_founding_access') return {restored: false};
  await store.linkOwner({ownerKey, entitlementOwnerKey: record.owner_key, productKey: record.product_key});
  return {restored: true};
}
