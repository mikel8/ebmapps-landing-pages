import {inspect} from './engine.mjs';

const text=(html,re)=>[...html.matchAll(re)].map(x=>x[1]||'').filter(Boolean);
export function inspectArchiveHtml(source,html,{finalUrl=source.archiveUrl,status=200}={}){
  const base=inspect(html,finalUrl),links=base.links||[];
  const articleLinks=links.filter(link=>/\/(?:post|posts|blog|essays|article|articles)\//i.test(new URL(link.url).pathname));
  const dateEvidence=(html.match(/(?:datePublished|article:published_time|<time\b)/gi)||[]).length;
  const relNext=text(html,/<link[^>]+rel=["']next["'][^>]+href=["']([^"']+)/gi);
  const numbered=links.filter(x=>/^\s*\d{1,3}\s*$/.test(x.label));
  const olderNewer=links.filter(x=>/older|newer|next|previous/i.test(x.label));
  const olderNewerSignals=(html.match(/older\s+posts|newer\s+posts|\bnext\b|\bprevious\b/gi)||[]).length;
  const loadMore=(html.match(/load more|infinite.scroll|infinite-scroll|data-next-page/gi)||[]).length;
  const feeds=[...html.matchAll(/<link\b([^>]*)>/gi)].flatMap(match=>{const attrs=match[1],type=attrs.match(/\btype\s*=\s*["']([^"']+)/i)?.[1]||'',href=attrs.match(/\bhref\s*=\s*["']([^"']+)/i)?.[1]||'';try{return /application\/(?:rss|atom)\+xml/i.test(type)?[new URL(href,finalUrl).href]:[]}catch{return[]}}).filter(url=>{try{return new URL(url).origin===source.origin}catch{return false}});
  const sitemaps=[...new Set([...text(html,/<a[^>]+href=["']([^"']*(?:sitemap|\.xml)[^"']*)["']/gi), ...[...html.matchAll(/<link\b([^>]*)>/gi)].filter(x=>/\brel\s*=\s*["'][^"']*\bsitemap\b/i.test(x[1])).map(x=>x[1].match(/\bhref\s*=\s*["']([^"']+)/i)?.[1]).filter(Boolean)])];
  const jsonLd=html.match(/application\/ld\+json/gi)||[];
  const jsonLdUrls=[...html.matchAll(/"(?:url|@id)"\s*:\s*"(https?:[^"\\]+|\/[^"\\]+)"/g)].map(x=>x[1]);
  const jsonLdArticle=(html.match(/(?:BlogPosting|\"Article\"|\"ItemList\")/g)||[]).length;
  const title=(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'').replace(/<[^>]+>/g,' ').trim();
  const canonical=html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)/i)?.[1]||finalUrl;
  const genericStaticLinks=links.filter(link=>{const u=new URL(link.url);return u.href!==source.archiveUrl&&u.pathname!=='/'&&!/\/(?:about|contact|privacy|terms|login|tag|category)(?:\/|$)|\.(?:png|jpe?g|gif|svg|css|js|pdf|xml)$/i.test(u.pathname)&&link.label.trim().length>=4&&!/^(home|about|contact|archive|blog|posts?|tags?|categories?|search|subscribe|rss|next|previous|older|newer|read more)$/i.test(link.label.trim())});
  return {source,finalUrl,status,bytes:Buffer.byteLength(html),title,canonical,articleElements:base.evidence.articleTags,repeatedBlocks:base.evidence.repeatedBlocks,likelyArticleLinks:articleLinks,genericStaticLinks,dateEvidence,pagination:{relNext,numberedPages:numbered.length,olderNewer:olderNewer.length+olderNewerSignals},loadMore,feeds,sitemaps,jsonLd:{scripts:jsonLd.length,articleOrItemList:jsonLdArticle,urls:jsonLdUrls},rawDiagnostics:base};
}

export async function inspectArchive(source,{fetchImpl=globalThis.fetch}={}){const response=await fetchImpl(source.archiveUrl,{headers:{'user-agent':'BlogToBook Brian vertical slice/0.3'}});const html=await response.text();if(!response.ok)throw Error(`Archive returned HTTP ${response.status}`);return {...inspectArchiveHtml(source,html,{finalUrl:response.url||source.archiveUrl,status:response.status}),html}}
