import crypto from 'node:crypto';
import {hashPurchaseEmail} from './billing-recovery.mjs';

export const FOUNDING_ACCESS_PRODUCT = 'blogtobook_founding_access';
export const FOUNDING_ACCESS_PRICE_CENTS = 1900;

export function verifyStripeSignature(payload, header, secret, toleranceSeconds = 300, now = Date.now()) {
  if (!payload || !header || !secret) return false;
  const values = Object.fromEntries(String(header).split(',').map(part => part.split('=')));
  const timestamp = Number(values.t);
  if (!Number.isFinite(timestamp) || Math.abs(now / 1000 - timestamp) > toleranceSeconds) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${timestamp}.${payload}`).digest('hex');
  if (typeof values.v1 !== 'string') return false;
  const supplied = Buffer.from(values.v1);
  return supplied.length === expected.length && crypto.timingSafeEqual(Buffer.from(expected), supplied);
}

export async function processStripeEvent(event, store, options = {}) {
  if (!event?.id || !event.type || !store?.hasEvent || !store?.recordEvent) throw new Error('Invalid billing event');
  if (await store.hasEvent(event.id)) {
    // A previously acknowledged checkout may predate passwordless recovery.
    // Backfill only the verified Checkout email hash; never grant access here.
    const object = event.data?.object || {};
    const metadata = object.metadata || {};
    const emailHash = hashPurchaseEmail(object.customer_details?.email || object.customer_email, options.emailHashSecret);
    if (event.type === 'checkout.session.completed' && metadata.product === FOUNDING_ACCESS_PRODUCT && metadata.owner && emailHash && store.backfillEmailHash) {
      await store.backfillEmailHash(metadata.owner, emailHash, object.id || null);
      return { duplicate: true, emailBackfilled: true };
    }
    return { duplicate: true };
  }
  const object = event.data?.object || {};
  const metadata = object.metadata || {};
  if (metadata.product !== FOUNDING_ACCESS_PRODUCT) {
    await store.recordEvent(event.id, { ignored: true, eventType: event.type });
    return { ignored: true };
  }
  let owner = metadata.owner;
  if (!owner && (event.type === 'charge.refunded' || event.type === 'refund.created') && object.payment_intent && store.findEntitlementByPaymentIntent) {
    owner = (await store.findEntitlementByPaymentIntent(object.payment_intent))?.owner_key;
  }
  if (!owner) throw new Error('Billing event has no owner');
  if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') {
    if (object.payment_status && object.payment_status !== 'paid') return { pending: true };
    await store.grant(owner, { product: FOUNDING_ACCESS_PRODUCT, sourceEvent: event.id, customerId: object.customer || null, sessionId: object.id || null, paymentIntentId: object.payment_intent || null, referenceId: object.client_reference_id || null, emailHash: hashPurchaseEmail(object.customer_details?.email || object.customer_email, options.emailHashSecret) });
  } else if (event.type === 'charge.refunded' || event.type === 'refund.created') {
    // Stripe's charge.amount_refunded is cumulative across partial refunds.
    // Only revoke when the verified cumulative amount reaches the original charge.
    const amount = Number(object.amount), amountRefunded = Number(object.amount_refunded);
    if (Number.isFinite(amount) && Number.isFinite(amountRefunded) && amount > 0 && amountRefunded >= amount) {
      await store.revoke(owner, { product: FOUNDING_ACCESS_PRODUCT, sourceEvent: event.id });
    }
  } else {
    await store.recordEvent(event.id, { ignored: true, eventType: event.type });
    return { ignored: true };
  }
  await store.recordEvent(event.id, { processed: true, eventType: event.type });
  return { processed: true };
}
