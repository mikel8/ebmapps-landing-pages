import { FOUNDING_ACCESS_PRODUCT, FOUNDING_ACCESS_PRICE_CENTS } from './billing.mjs';

export function checkoutConfig(env = process.env) {
  const hosted = env.BTB_RUNTIME === 'hosted' || env.NODE_ENV === 'production';
  return {
    priceId: env.BLOGTOBOOK_STRIPE_PRICE_ID || null,
    successUrl: env.BLOGTOBOOK_CHECKOUT_SUCCESS_URL || (hosted ? 'https://blogtobook.fly.dev/?billing=success' : 'http://localhost:4173/?billing=success'),
    cancelUrl: env.BLOGTOBOOK_CHECKOUT_CANCEL_URL || (hosted ? 'https://blogtobook.fly.dev/?billing=cancelled' : 'http://localhost:4173/?billing=cancelled')
  };
}

export async function createFoundingAccessCheckout(stripe, { ownerKey, customerId = null, referenceId = null, analyticsId = null, trafficClass = null, env = process.env } = {}) {
  if (!stripe?.checkout?.sessions?.create) throw new Error('Stripe checkout client unavailable');
  if (!ownerKey || typeof ownerKey !== 'string') throw new Error('ownerKey is required');
  const cfg = checkoutConfig(env);
  if (!cfg.priceId) throw new Error('BLOGTOBOOK_STRIPE_PRICE_ID is not configured');
  const metadata = { product: FOUNDING_ACCESS_PRODUCT, owner: ownerKey, price_cents: String(FOUNDING_ACCESS_PRICE_CENTS) };
  if (/^[0-9a-f-]{36}$/i.test(analyticsId || '') && ['external','internal'].includes(trafficClass)) { metadata.analytics_id = analyticsId; metadata.traffic_class = trafficClass; }
  return stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{ price: cfg.priceId, quantity: 1 }],
    success_url: cfg.successUrl,
    cancel_url: cfg.cancelUrl,
    client_reference_id: referenceId || ownerKey,
    customer: customerId || undefined,
    customer_creation: customerId ? undefined : 'always',
    metadata,
    payment_intent_data: {metadata},
    allow_promotion_codes: false
  });
}

export function createSupabaseBillingStore(client) {
  if (!client?.from) throw new Error('Supabase client unavailable');
  const table = name => client.from(name);
  return {
    async hasEvent(id) { const { data, error } = await table('blogtobook_webhook_events').select('stripe_event_id').eq('stripe_event_id', id).maybeSingle(); if (error) throw error; return !!data; },
    async recordEvent(id, details = {}) { const { error } = await table('blogtobook_webhook_events').upsert({ stripe_event_id: id, event_type: details.eventType || null, processed_at: new Date().toISOString() }); if (error) throw error; },
    async grant(ownerKey, details = {}) { const { error } = await table('blogtobook_entitlements').upsert({ owner_key: ownerKey, product_key: FOUNDING_ACCESS_PRODUCT, stripe_customer_id: details.customerId || null, status: 'active', updated_at: new Date().toISOString() }, { onConflict: 'owner_key,product_key' }); if (error) throw error; },
    async revoke(ownerKey) { const { error } = await table('blogtobook_entitlements').update({ status: 'revoked', updated_at: new Date().toISOString() }).eq('owner_key', ownerKey).eq('product_key', FOUNDING_ACCESS_PRODUCT); if (error) throw error; },
    async getEntitlement(ownerKey) { const { data, error } = await table('blogtobook_entitlements').select('owner_key,product_key,status,first_export_used').eq('owner_key', ownerKey).eq('product_key', FOUNDING_ACCESS_PRODUCT).maybeSingle(); if (error) throw error; return data; },
    async markFirstExport(ownerKey) { const { error } = await table('blogtobook_entitlements').update({ first_export_used: true, updated_at: new Date().toISOString() }).eq('owner_key', ownerKey).eq('product_key', FOUNDING_ACCESS_PRODUCT); if (error) throw error; }
  };
}
