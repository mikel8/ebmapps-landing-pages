import {discoverArticleLinks} from './article-links.mjs';
import {detectPagination} from './pagination.mjs';

// A profile is evidence from the first page, not a completeness claim.
export function profileArchiveStructure(source,html,inspection){
  const candidates=discoverArticleLinks(source,html,{inspection}).candidates;
  const groups=new Map();
  for(const match of html.matchAll(/<(article|div|section|li)\b([^>]*)>/gi)){
    const tag=match[1].toLowerCase(),classes=(match[2].match(/\bclass\s*=\s*["']([^"']*)/i)?.[1]||'').split(/\s+/).filter(Boolean).sort();
    if(tag!=='article'&&!classes.length)continue;
    const key=tag+(classes.length?'.'+classes.join('.'):'');groups.set(key,(groups.get(key)||0)+1);
  }
  const repeatedContainers=[...groups].filter(([,count])=>count>1).map(([signature,count])=>({signature,count})).sort((a,b)=>b.count-a.count).slice(0,30);
  const patterns=new Map();for(const c of candidates){try{const path=new URL(c.canonicalUrl).pathname;const pattern=path.split('/').map(part=>/^\d+$/.test(part)?'{number}':part).slice(0,-1).join('/')+'/{slug}';patterns.set(pattern,(patterns.get(pattern)||0)+1)}catch{}}
  const images=[...html.matchAll(/<img\b([^>]*)>/gi)].map(x=>x[1].match(/\b(?:src|data-src)\s*=\s*["']([^"']+)/i)?.[1]).filter(Boolean).map(raw=>{try{return new URL(raw,inspection.finalUrl).href}catch{return raw}});
  const pagination=detectPagination(html,source,inspection.finalUrl||source.archiveUrl);
  return {repeatedContainers,articleCandidates:candidates.map(c=>({url:c.canonicalUrl,title:c.title,date:c.publicationDate})),urlPatterns:[...patterns].map(([pattern,count])=>({pattern,count})),titleCount:candidates.filter(c=>c.title).length,dateCount:candidates.filter(c=>c.publicationDate).length,imageCount:images.length,images,canonical:inspection.canonical,jsonLd:inspection.jsonLd,feeds:inspection.feeds,sitemaps:inspection.sitemaps,pagination};
}
