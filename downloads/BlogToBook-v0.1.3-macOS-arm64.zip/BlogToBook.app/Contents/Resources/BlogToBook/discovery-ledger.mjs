// Per-inspection evidence; never shares mutable state between jobs.
export function createDiscoveryLedger({replay={}}={}){
  const entries=[],seen=new Set(), cache={...replay}; let cacheBytes=Object.values(cache).reduce((n,x)=>n+Buffer.byteLength(x.body||''),0);
  const latest=url=>[...entries].reverse().find(x=>x.finalUrl===url||x.requestedUrl===url);
  return {
    entries,
    async fetch(url,options={}){
      const entry={requestedUrl:String(url),finalUrl:null,status:null,ok:false,error:null,articleCount:null,newUrls:[],duplicateUrls:[],continuationUrls:[],stopReason:null,attempts:0};entries.push(entry);
      const saved=cache[String(url)];
      if(saved){entry.finalUrl=saved.url;entry.status=saved.status;entry.ok=true;entry.replayed=true;const response=new Response(saved.body,{status:saved.status,headers:saved.headers});Object.defineProperty(response,'url',{value:saved.url});return response}
      for(let attempt=0;attempt<3;attempt++){
        entry.attempts++;
        const timeout=AbortSignal.timeout(15000),signal=options.signal?AbortSignal.any([options.signal,timeout]):timeout;
        try{
          const response=await globalThis.fetch(url,{...options,signal});entry.finalUrl=response.url||String(url);entry.status=response.status;entry.ok=response.ok;
          if([502,503,504].includes(response.status)&&attempt<2){await response.body?.cancel?.();continue}
          entry.error=null;if(response.ok&&response.status!==204){const body=await (typeof response.clone==='function'?response.clone():response).text(),bytes=Buffer.byteLength(body);if(cacheBytes+bytes<=25*1024*1024){cache[String(url)]={url:entry.finalUrl,status:response.status,headers:{'content-type':response.headers?.get?.('content-type')||'text/html'},body};cacheBytes+=bytes}}return response;
        }catch(error){entry.error=error.code||error.name||'FETCH_FAILED';if(attempt<2&&!options.signal?.aborted&&['FETCH_FAILED','FETCH_TIMEOUT','TimeoutError','TypeError'].includes(entry.error))continue;throw error}
      }
    },
    parsed(url,candidates,continuations=[]){const entry=latest(url);if(!entry)return;if(entry.articleCount!==null)return;entry.articleCount=candidates.length;entry.newUrls=[];entry.duplicateUrls=[];entry.continuationUrls=continuations.map(x=>typeof x==='string'?x:x.url).filter(Boolean);for(const item of candidates){const key=item.canonicalUrl;if(!key)continue;if(seen.has(key))entry.duplicateUrls.push(key);else{seen.add(key);entry.newUrls.push(key)}}},
    stop(url,reason){const entry=latest(url);if(entry)entry.stopReason=reason},
    snapshot(){return {entries:structuredClone(entries),uniqueArticleUrls:seen.size}},
    replaySnapshot(){return structuredClone(cache)}
  };
}
