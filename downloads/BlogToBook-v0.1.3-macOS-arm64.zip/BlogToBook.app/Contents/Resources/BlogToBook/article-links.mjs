import {resolveUrl} from './engine.mjs';
import {articleCandidate} from './pipeline.mjs';
import {htmlText} from './text-normalize.mjs';

const clean=htmlText;
const excluded=url=>{const path=new URL(url).pathname;return path==='/'||/\/(?:about|contact|privacy|terms|login|signup|sign-in|sign-up|authors?|tag|tags|category|categories)(?:\/|$)|\.(?:png|jpe?g|gif|svg|css|js|pdf)$/i.test(path)};
function candidateUrl(raw,source){return resolveUrl(raw,source.archiveUrl,source.origin)}
function anchors(html){return [...html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)].map(match=>{const attrs=match[1],href=attrs.match(/\bhref\s*=\s*["']([^"']*)["']/i)?.[1];return {raw:match[0],href,text:match[2]}}).filter(x=>x.href)}
function fromBlock(block,source,index){
  const links=anchors(block).map(x=>[x.href,x.text]);
  const heading=block.match(/<h[1-4]\b[^>]*>([\s\S]*?)<\/h[1-4]>/i)?.[1];
  const picked=links.find(x=>heading&&x[1].includes(heading))||links[0];if(!picked)return [];
  const url=candidateUrl(picked[0],source);if(!url||excluded(url))return [];
  const title=clean(heading||picked[1]);if(!title||title.length<2||/^(home|archive|blog|posts?|next|previous|older|newer|read more|more)$/i.test(title))return [];
  const date=block.match(/<time\b[^>]*>([\s\S]*?)<\/time>/i);const publicationDate=block.match(/<time\b[^>]*datetime=["']([^"']+)/i)?.[1]||clean(date?.[1]);
  const excerpt=clean(block.replace(/<a\b[\s\S]*?<\/a>/gi,'').replace(/<time\b[\s\S]*?<\/time>/gi,''));
  return [articleCandidate({url,title,date:publicationDate,blocks:excerpt?[{type:'p',text:excerpt}]:[],words:excerpt?excerpt.split(/\s+/).length:0,status:'metadata only'},{source,provenance:{executor:'article-link archive',structure:'repeated card',index}})];
}
function fromHeadingEntries(html,source){
  const headings=[...html.matchAll(/<h[1-4]\b[^>]*>([\s\S]*?)<\/h[1-4]>/gi)];
  return headings.flatMap((match,index)=>{
    const heading=match[1],inside=anchors(heading)[0],prefix=html.slice(Math.max(0,match.index-5000),match.index),opens=[...prefix.matchAll(/<a\b([^>]*)>/gi)],lastClose=prefix.lastIndexOf('</a>'),parent=opens.filter(x=>x.index>lastClose).at(-1),parentHref=parent?.[1]?.match(/\bhref\s*=\s*["']([^"']*)["']/i)?.[1],link=inside||{href:parentHref,text:heading};if(!link?.href)return [];
    const url=candidateUrl(link.href,source);if(!url||excluded(url))return [];
    const title=clean(heading);if(!title||title.length<2||/^(home|about|contact|archive|blog|posts?|categories|tags|authors?|next|previous|older|newer|read more|more)$/i.test(title))return [];
    const tail=html.slice(match.index+match[0].length,match.index+match[0].length+500);
    const previousHeading=html.slice(0,match.index).lastIndexOf('</h');const before=html.slice(Math.max(0,previousHeading,match.index-5000),match.index);const preceding=[...before.matchAll(/<time\b[^>]*datetime=["']([^"']+)/gi)].at(-1)?.[1];const date=preceding||tail.match(/<time\b[^>]*datetime=["']([^"']+)/i)?.[1]||clean(tail.match(/<time\b[^>]*>([\s\S]*?)<\/time>/i)?.[1]);
    const excerpt=clean(tail.match(/<p\b[^>]*>([\s\S]*?)<\/p>/i)?.[1]||'');
    return [articleCandidate({url,title,date,blocks:excerpt?[{type:'p',text:excerpt}]:[],words:excerpt?excerpt.split(/\s+/).length:0,status:'metadata only'},{source,provenance:{executor:'article-link archive',structure:'repeated heading link',index}})];
  });
}
function jsonLdCandidates(html,source){const out=[];for(const match of html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)){try{const visit=value=>{if(!value||typeof value!=='object')return;if(Array.isArray(value))return value.forEach(visit);const type=Array.isArray(value['@type'])?value['@type'].join(' '):value['@type']||'';if(/ItemList|Article|BlogPosting/i.test(type)){const raw=value.url||value.mainEntityOfPage?.['@id'];const url=raw&&candidateUrl(raw,source);if(url&&!excluded(url))out.push(articleCandidate({url,title:value.headline||value.name||'',date:value.datePublished||'',blocks:[],status:'metadata only'},{source,provenance:{executor:'article-link archive',structure:'json-ld'}}))}Object.values(value).forEach(visit)};visit(JSON.parse(match[1]))}catch{}}return out}
export function discoverArticleLinks(source,html,{inspection}={}){const blocks=[...html.matchAll(/<article\b[^>]*>([\s\S]*?)<\/article>|<(?:div|section)\b[^>]*class=["'][^"']*(?:post|article|entry|card)[^"']*["'][^>]*>([\s\S]*?)<\/(?:div|section)>/gi)].map(x=>x[1]||x[2]);const blockCandidates=blocks.flatMap((block,index)=>fromBlock(block,source,index));const headingCandidates=fromHeadingEntries(html,source);const raw=[...blockCandidates,...headingCandidates,...jsonLdCandidates(html,source)];const byUrl=new Map;for(const item of raw){const previous=byUrl.get(item.canonicalUrl);if(!previous)byUrl.set(item.canonicalUrl,item);else if(!previous.publicationDate&&item.publicationDate)previous.publicationDate=previous.date=item.publicationDate;}const candidates=[...byUrl.values()];return {candidates,diagnostics:{executor:'article-link archive',scannedStructures:blocks.length,headingStructures:headingCandidates.length,rawCandidates:raw.length,deduplicated:raw.length-candidates.length,rejected:Math.max(0,blocks.length+headingCandidates.length-raw.length),pagination:inspection?.pagination||{}},warnings:candidates.some(x=>!x.publicationDate)?['Some article-link candidates have no archive-derived publication date']:[]}}
