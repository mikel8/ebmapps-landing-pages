import crypto from 'node:crypto';
import fs from 'node:fs/promises';

export function createAnalytics({dataDir, fetchImpl=globalThis.fetch}={}) {
  const key=process.env.POSTHOG_API_KEY, host=(process.env.POSTHOG_HOST||'https://us.i.posthog.com').replace(/\/$/,'');
  let idPromise;
  async function installationId(){if(!idPromise)idPromise=(async()=>{const file=`${dataDir}/analytics-id`;try{return (await fs.readFile(file,'utf8')).trim()}catch{const id=crypto.randomUUID();await fs.writeFile(file,id,{flag:'wx'}).catch(()=>{});return id}})();return idPromise}
  const allowed=new Set(['app_started','source_submitted','archive_inspection_started','archive_inspection_completed','archive_inspection_failed','crawl_started','crawl_completed','crawl_cancelled','crawl_failed','review_opened','review_selection_changed','epub_export_started','epub_export_completed','epub_export_failed']);
  const diagnostics=process.env.BTB_ANALYTICS_DIAGNOSTICS==='1';
  return {enabled:Boolean(key&&process.env.NODE_ENV==='production'), async capture(event,properties={}){if(!key||process.env.NODE_ENV!=='production'||!allowed.has(event))return;const surface=process.env.BTB_RUNTIME==='hosted'?'web':'mac';try{const response=await fetchImpl(`${host}/capture/`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({api_key:key,event,distinct_id:await installationId(),properties:{app_name:'BlogToBook',app_version:'0.1.0',surface,...properties}})});if(diagnostics)console.info('[analytics:capture]',event,'status='+String(response?.status??'unknown'),'surface='+surface);if(response && response.ok===false)return false;return true}catch(error){if(diagnostics)console.info('[analytics:capture]',event,'error='+String(error?.name||'Error'),'surface='+surface);return false}}};
}
