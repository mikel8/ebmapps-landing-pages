import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {counts,idFor} from './engine.mjs';
import {epubBuffer} from './epub.mjs';
import {sourceFromInput} from './source.mjs';
import {discover,selectValidationSamples} from './discovery.mjs';
import {runCrawl,createJob,cancelJob,reconcile,processCandidate} from './crawler.mjs';
import {createWorkflow,consumeWorkflow,projectJob,storeJob,getJob} from './workflow.mjs';
import {reviewCollection} from './review.mjs';
import {assembleBook,renderBookEpub} from './book.mjs';
import {acquireImages,hydrateImageAssets} from './image-cache.mjs';
import {runtimePaths} from './runtime-paths.mjs';
import {createAnalytics} from './analytics.mjs';
import {createHostedRuntime,hostedArtifactName} from './hosted-runtime.mjs';
import {createHostedFetchGuard} from './hosted-fetch.mjs';
import {assessArticle} from './quality.mjs';
import {hostedInspectionProjection} from './discovery-report.mjs';
import {runHostedCrawl} from './hosted-crawl.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
const paths=runtimePaths({root}),data=paths.data,dbFile=paths.dbFile,artifacts=paths.artifacts,imageDir=paths.imageDir;
const hostedMode=process.env.BTB_RUNTIME==='hosted';
// Capture the platform fetch before the hosted crawler installs its GET-only
// SSRF guard. Telemetry has a fixed, application-owned destination and must
// retain POST semantics; crawler requests remain guarded below.
const analytics=createAnalytics({dataDir:data,fetchImpl:globalThis.fetch});
const hostedFetch=hostedMode?createHostedFetchGuard():null;
if(hostedFetch)hostedFetch.install();
const hosted=hostedMode?await createHostedRuntime({root:process.env.BTB_HOSTED_ROOT||path.join(data,'hosted-jobs')}):null;
if(hosted){await hosted.recoverInterrupted();await hosted.cleanup();setInterval(()=>void hosted.cleanup(),15*60*1000).unref()}
await fs.mkdir(artifacts,{recursive:true});
const BRIAN_EXPORT_SOURCE='https://brianbalfour.com/essays';
await fs.mkdir(data,{recursive:true});
await fs.mkdir(imageDir,{recursive:true});
async function readDb(){try{return JSON.parse(await fs.readFile(dbFile,'utf8'))}catch{return {items:[],jobs:{}}}}
let writeQueue=Promise.resolve();async function writeDb(x){const body=JSON.stringify(x,null,2),tmp=dbFile+'.tmp';writeQueue=writeQueue.then(async()=>{await fs.writeFile(tmp,body);await fs.rename(tmp,dbFile)});return writeQueue}
async function readBody(req){let s='';for await(const c of req)s+=c;return JSON.parse(s||'{}')}
function send(res,status,value,type='application/json'){res.writeHead(status,{'content-type':type});res.end(type==='application/json'?JSON.stringify(value):value);return true}

const HOSTED_QUEUE_LIMIT=8;let hostedRunning=false;const hostedQueue=[],hostedCrawls=new Map();
function canQueueHosted(){return hostedQueue.length<HOSTED_QUEUE_LIMIT}
function queueHosted(task){if(!canQueueHosted())return false;hostedQueue.push(task);void drainHosted();return true}
async function drainHosted(){if(hostedRunning)return;hostedRunning=true;try{while(hostedQueue.length)await hostedQueue.shift()()}finally{hostedRunning=false}}
function hostedProgress(crawl){const r=reconcile(crawl);return {total:r.total,processed:r.terminal,success:r.SUCCESS,reused:r.REUSED,previews:r.PUBLIC_PREVIEW,previewsReused:r.REUSED_PREVIEW,failed:r.failed,cancelled:r.CANCELLED}}
async function inspectHosted(id){
  let job=await hosted.read(id);if(job.state==='CANCELLED')return;
  await hosted.transition(id,'INSPECTING');
  try{const result=await hostedFetch.withJob(job,()=>discover(job.source,{limits:job.limits}));job=await hosted.read(id);if(job.state==='CANCELLED')return;const discovery=result.diagnostics.discovery,completeness=discovery.completeness,inspection=hostedInspectionProjection(result,job.limits);await hosted.writeJson(id,'candidates.json',result.candidates);await hosted.transition(id,'READY',{inspection});await analytics.capture('archive_inspection_completed',{surface:'web',discovery_strategy:result.strategy,candidate_count:result.candidates.length,archive_page_count:discovery.archivePagesInspected,completeness:completeness.status})}
  catch(error){job=await hosted.read(id);if(job.state!=='CANCELLED'){await hosted.transition(id,'FAILED',{error:{category:'INSPECTION_FAILED',message:'Archive inspection could not be completed.'}});await analytics.capture('archive_inspection_failed',{surface:'web',failure_category:'network_or_fetch'})}}
}
async function crawlHosted(id){
  let job=await hosted.read(id);if(job.state==='CANCELLED')return;
  const discoveredCandidates=await hosted.readJson(id,'candidates.json'),candidates=discoveredCandidates.slice(0,job.limits.maxCrawledArticles),articles=await hosted.readJson(id,'articles.json'),assets=await hosted.readJson(id,'assets.json');
  let crawl;
  try{const result=await runHostedCrawl({job,candidates,articles,assets,imageDir:path.join(hosted.jobDir(id),'images'),fetchGuard:hostedFetch,imageLimits:{maxImages:job.limits.maxImages,maxBytes:job.limits.maxImageBytes,concurrency:4,timeoutMs:15_000},persist:async state=>{crawl=state.crawl;hostedCrawls.set(id,crawl);await hosted.writeJson(id,'articles.json',articles);await hosted.writeJson(id,'assets.json',assets);await hosted.writeJson(id,'outcomes.json',state.failures||[]);const current=await hosted.read(id);if(current.state==='CANCELLED')cancelJob(crawl);else await hosted.patch(id,{progress:hostedProgress(crawl),resources:{...state.budget,imageStats:state.imageStats}})}});crawl=result.crawl;hostedCrawls.set(id,crawl);await hosted.writeJson(id,'outcomes.json',result.failures);job=await hosted.read(id);if(job.state!=='CANCELLED'){const p=hostedProgress(crawl);await hosted.transition(id,'REVIEW',{progress:p,resources:{...result.budget,imageStats:result.imageStats},review:{available:p.success+p.reused+p.previews+p.previewsReused,publicPreviews:p.previews+p.previewsReused,excluded:p.failed,failures:result.failures}});await analytics.capture('crawl_completed',{surface:'web',article_count:p.total,success_count:p.success,reused_count:p.reused,failure_count:p.failed})}}
  catch(error){job=await hosted.read(id);if(job.state!=='CANCELLED'){await hosted.transition(id,'FAILED',{error:{category:'CRAWL_FAILED',message:'Archive crawl could not be completed.'},progress:crawl?hostedProgress(crawl):job.progress});await analytics.capture('crawl_failed',{surface:'web',failure_category:'crawl_error'})}}
  finally{hostedCrawls.delete(id)}
}
function safeReview(result,selection=[]){return {...result,source:undefined,articles:result.articles.map(a=>({...a,canonicalUrl:undefined,included:selection.includes(a.id)}))}}
async function exportHosted(id){try{const job=await hosted.read(id),items=await hosted.readJson(id,'articles.json'),selection=await hosted.readJson(id,'selection.json'),assets=await hosted.readJson(id,'assets.json'),localAssets=await hydrateImageAssets(assets,path.join(hosted.jobDir(id),'images')),book=assembleBook(job.source,selection,items,{imageAssets:localAssets}),buffer=renderBookEpub(book),name=hostedArtifactName(id);await hosted.writeArtifact(id,name,buffer);const refs=book.chapters.flatMap(x=>x.blocks.filter(b=>b.type==='image')),skipped=refs.filter(b=>b.imageState!=='available').length;await hosted.transition(id,'COMPLETE',{export:{chapters:book.chapters.length,words:book.wordCount,publicPreviews:book.publicPreviews,imagesPackaged:book.images.length,imagesSkipped:skipped,bytes:buffer.length}});await analytics.capture('epub_export_completed',{surface:'web',selected_article_count:book.chapters.length,word_count:book.wordCount,packaged_image_count:book.images.length,skipped_image_count:skipped,artifact_bytes:buffer.length})}catch(error){console.error('[hosted:export:error]',id,error?.name||'Error',error?.message||'Unknown export failure');const job=await hosted.read(id);if(job.state!=='CANCELLED')await hosted.transition(id,'FAILED',{error:{category:'EXPORT_FAILED',message:'The book could not be prepared.'}});await analytics.capture('epub_export_failed',{surface:'web',failure_category:'export_error'})}}
async function hostedApi(req,res){
  const pathname=new URL(req.url,'http://localhost').pathname,match=pathname.match(/^\/api\/jobs\/([A-Za-z0-9_-]+)(?:\/(crawl|cancel|review|selection|export|download))?$/);
  try{
    if(pathname==='/api/jobs'&&req.method==='POST'){const input=await readBody(req),source=sourceFromInput(input.archiveUrl);hostedFetch.validateUrl(source.archiveUrl);const job=await hosted.create({source});if(!queueHosted(()=>inspectHosted(job.id))){await hosted.transition(job.id,'FAILED',{error:{category:'QUEUE_FULL',message:'The hosted processing queue is currently full.'}});return send(res,429,{error:'The hosted processing queue is currently full.'})}await analytics.capture('source_submitted',{surface:'web'});send(res,202,{jobId:job.id,state:job.state});return true}
    if(match&&req.method==='GET'&&!match[2]){const job=await hosted.read(match[1]);send(res,200,hosted.status(job));return true}
    if(match&&match[2]==='crawl'&&req.method==='POST'){let job=await hosted.read(match[1]);if(job.state!=='READY')return send(res,409,{error:'This job is not ready to crawl'});if(!canQueueHosted())return send(res,429,{error:'The hosted processing queue is currently full.'});job=await hosted.transition(job.id,'CRAWLING');if(!queueHosted(()=>crawlHosted(job.id))){await hosted.transition(job.id,'FAILED',{error:{category:'QUEUE_FULL',message:'The hosted processing queue is currently full.'}});return send(res,429,{error:'The hosted processing queue is currently full.'})}send(res,202,hosted.status(job));return true}
    if(match&&match[2]==='review'&&req.method==='GET'){const job=await hosted.read(match[1]);if(job.state!=='REVIEW'&&job.state!=='COMPLETE')return send(res,409,{error:'Review is not available yet'});const items=await hosted.readJson(job.id,'articles.json'),failures=await hosted.readJson(job.id,'outcomes.json').catch(()=>[]),selection=job.state==='COMPLETE'?(await hosted.readJson(job.id,'selection.json')).articleIds:[],result=reviewCollection(job.source,items,{failures});await analytics.capture('review_opened',{surface:'web',article_count:result.articles.length});return send(res,200,safeReview(result,selection))}
    if(match&&match[2]==='selection'&&req.method==='POST'){const job=await hosted.read(match[1]);if(job.state!=='REVIEW')return send(res,409,{error:'Selection is not available in this state'});const input=await readBody(req),items=await hosted.readJson(job.id,'articles.json'),eligible=items.filter(x=>assessArticle(x).eligible),valid=new Set(eligible.map(x=>x.id)),ids=Array.isArray(input.articleIds)?[...new Set(input.articleIds)]:[];if(!ids.length)return send(res,400,{error:'Select at least one article.'});if(ids.some(id=>!valid.has(id)))return send(res,400,{error:'One or more selected articles are unavailable.'});await hosted.writeJson(job.id,'selection.json',{articleIds:ids,chronology:input.chronology||'UNKNOWN_CHRONOLOGY'});await hosted.patch(job.id,{review:{available:eligible.length,selected:ids.length}});await analytics.capture('review_selection_changed',{surface:'web',selected_article_count:ids.length});return send(res,200,{selected:ids.length,total:eligible.length})}
    if(match&&match[2]==='export'&&req.method==='POST'){const job=await hosted.read(match[1]);if(job.state!=='REVIEW')return send(res,409,{error:'This job is not ready to export'});const input=await readBody(req);if(Array.isArray(input.articleIds)){const items=await hosted.readJson(job.id,'articles.json'),valid=new Set(items.filter(x=>assessArticle(x).eligible).map(x=>x.id)),ids=[...new Set(input.articleIds)];if(!ids.length||ids.some(id=>!valid.has(id)))return send(res,400,{error:'Select valid articles before exporting.'});await hosted.writeJson(job.id,'selection.json',{articleIds:ids,chronology:input.chronology||'UNKNOWN_CHRONOLOGY'});}else if(!(await hosted.readJson(job.id,'selection.json').catch(()=>null)))return send(res,400,{error:'Select at least one article.'});await hosted.transition(job.id,'EXPORTING');await analytics.capture('epub_export_started',{surface:'web'});if(!queueHosted(()=>exportHosted(job.id)))return send(res,429,{error:'The hosted processing queue is currently full.'});return send(res,202,hosted.status(await hosted.read(job.id)))}
    if(match&&match[2]==='download'&&req.method==='GET'){const job=await hosted.read(match[1]);if(!job.artifact)return send(res,404,{error:'This download has expired.'});const bytes=await hosted.readArtifact(job.id,job.artifact.name);res.writeHead(200,{'content-type':'application/epub+zip','content-disposition':`attachment; filename="${job.artifact.name}"`});res.end(bytes);return true}
    if(match&&match[2]==='cancel'&&req.method==='POST'){const job=await hosted.requestCancel(match[1]);const crawl=hostedCrawls.get(job.id);if(crawl)cancelJob(crawl);send(res,200,hosted.status(job));return true}
    if(pathname.startsWith('/api/')){send(res,404,{error:'Hosted API endpoint not found'});return true}
  }catch(error){const status=/Job not found|Illegal hosted job transition/.test(error.message)?404:400;send(res,status,{error:error.message});return true}
  return false
}

async function discoverBrian(source){
  const archive=new URL(source.archiveUrl);
  let page=source.archiveUrl,pages=0,all=[],seen=new Set(),lastHtml='';
  while(page&&pages<100&&!seen.has(page)){
    seen.add(page);
    const response=await fetch(page,{headers:{'user-agent':'BlogToBook Brian vertical slice/0.3'}});
    lastHtml=await response.text();
    if(!response.ok)throw Error(`Brian returned HTTP ${response.status}`);
    all.push(...segmentInline(lastHtml,page)); pages++;
    const match=lastHtml.match(/<a[^>]+class=["'][^"']*older-posts[^"']*["'][^>]+href=["']([^"']+)["']/i)||lastHtml.match(/<a[^>]+href=["']([^"']+)["'][^>]*>\s*Older Posts/i);
    if(!match)break;
    try{const next=new URL(match[1],page);const offset=next.searchParams.get('offset');if(next.origin!==archive.origin||next.pathname!==archive.pathname||!/^\d{1,16}$/.test(offset||''))break;page=next.href}catch{break}
  }
  const unique=[];const used=new Set();
  for(const item of all){const key=item.url||item.title;if(!used.has(key)){used.add(key);unique.push(item)}}
  unique.sort((a,b)=>(Date.parse(a.date)||Infinity)-(Date.parse(b.date)||Infinity));
  const pre=inspect(lastHtml,source.archiveUrl);pre.type='inline multi-article archive';pre.pagination={pagesFollowed:pages,olderPostsFound:pages>1};
  const samples=[unique[0],unique[Math.floor(unique.length/2)],unique.at(-1)].filter(Boolean).map(x=>({...x,bodySample:x.blocks.filter(b=>b.text).map(b=>b.text).join(' ').slice(0,280)}));
  return {preflight:pre,items:unique,samples};
}

async function startJob(workflow){
  const db=await readDb(),assets=db.imageAssets||[];const id=idFor(Date.now()+''),job=storeJob({...createJob(workflow.source,workflow.candidates,id),url:workflow.source.archiveUrl,preflight:workflow.diagnostics,startedAt:new Date().toISOString()});
  runCrawl(job,{cache:db.items,process:candidate=>processCandidate(candidate,db.items,{afterAccept:article=>acquireImages([article],{assets,imageDir})}),persist:async(items)=>{const now=await readDb();now.items=items;now.imageAssets=assets;await writeDb(now)}}).then(()=>analytics.capture(job.state==='COMPLETED'?'crawl_completed':job.state==='CANCELLED'?'crawl_cancelled':'crawl_failed',{article_count:job.total,success_count:job.outcomes.SUCCESS,reused_count:job.outcomes.REUSED,failure_count:job.outcomes.failed})).catch(error=>{job.state='FAILED';job.error=error.message;analytics.capture('crawl_failed',{failure_category:'runner_error'})});
  return {jobId:id,total:workflow.candidates.length};
}

const server=http.createServer(async(req,res)=>{try{
  if(hostedMode&&await hostedApi(req,res))return;
  if(req.url==='/api/preflight'&&req.method==='POST'){const input=await readBody(req);await analytics.capture('source_submitted');const source=sourceFromInput(input.archiveUrl);await analytics.capture('archive_inspection_started');let x;try{x=await discover(source)}catch(error){await analytics.capture('archive_inspection_failed',{failure_category:'network_or_fetch'});throw error}const workflow=createWorkflow(source,x.candidates,x.diagnostics),samples=selectValidationSamples(x),selection=x.diagnostics.strategy||{primary:x.strategy,confidence:0,evidence:[]},metadata=x.diagnostics.metadata||{},discovery=x.diagnostics.discovery,completeness=discovery.completeness,pagesFollowed=discovery.archivePagesInspected;await analytics.capture('archive_inspection_completed',{discovery_strategy:selection.primary,candidate_count:x.candidates.length,dated_candidate_count:metadata.dated||0,archive_page_count:pagesFollowed,completeness:completeness.status});return send(res,200,{workflowId:workflow.id,url:source.archiveUrl,archiveType:x.diagnostics.type||selection.primary,evidence:{...(x.diagnostics.evidence||{}),pagesFollowed,terminationReason:discovery.terminationReason,limitsReached:discovery.limitsReached,continuationRequestsFailed:discovery.continuationRequestsFailed,continuationStrategiesAttempted:discovery.continuationStrategiesAttempted,completeness},metadata,strategy:selection,discovered:x.candidates.length,sampleLabels:samples.labels,samples:[samples.oldest,samples.middle,samples.newest].filter(Boolean).map(a=>({...a,bodySample:a.previewBlocks.filter(b=>b.text).map(b=>b.text).join(' ').slice(0,280)}))})}
  if(req.url==='/api/crawl'&&req.method==='POST'){const input=await readBody(req);console.log('[api:crawl]',input.workflowId);if(input.confirm!==true||!input.workflowId)return send(res,400,{error:'Inspect the archive again before confirming'});const workflow=consumeWorkflow(input.workflowId);await analytics.capture('crawl_started',{article_count:workflow.candidates.length});console.log('[api:workflow]',workflow.id,workflow.candidates.length);const started=await startJob(workflow);console.log('[api:job]',started.jobId,started.total);return send(res,200,started)}
  if(req.url.startsWith('/api/job/')){const id=req.url.split('/').pop(),job=getJob(id),p=job&&projectJob(job);console.log('[api:job:get]',id,!!job,p?.state,p?.processed,p?.outcomes?.REUSED,p?.remaining);return job?send(res,200,p):send(res,404,{error:'Job not found'})}
  if(req.url==='/api/cancel'&&req.method==='POST'){const input=await readBody(req),job=getJob(input.jobId);if(job){cancelJob(job);await analytics.capture('crawl_cancelled',{article_count:job.total})}return send(res,200,{ok:true})}
  if(req.url==='/api/cache'){const db=await readDb();return send(res,200,{items:db.items,counts:counts(db.items)})}
  if(req.url==='/api/analytics'&&req.method==='POST'){const input=await readBody(req);await analytics.capture(input.event,input.properties&&typeof input.properties==='object'?input.properties:{});return send(res,204,'', 'text/plain')}
  if(new URL(req.url,'http://localhost').pathname==='/api/review'){const u=new URL(req.url,'http://localhost'),source=sourceFromInput(u.searchParams.get('archiveUrl')||''),db=await readDb(),result=reviewCollection(source,db.items);await analytics.capture('review_opened',{article_count:result.articles.length});return send(res,200,result)}
  if(req.url==='/api/images/backfill'&&req.method==='POST'){const input=await readBody(req),source=sourceFromInput(input.archiveUrl),db=await readDb(),items=db.items.filter(x=>x.source?.sourceId===source.sourceId&&assessArticle(x).eligible),result=await acquireImages(items,{assets:db.imageAssets||[],imageDir});db.imageAssets=result.assets;await writeDb(db);return send(res,200,result.stats)}
  if(req.url==='/api/export'&&req.method==='POST'){const input=await readBody(req),source=sourceFromInput(input.archiveUrl),db=await readDb(),selection={articleIds:Array.isArray(input.articleIds)?[...new Set(input.articleIds)]:[],chronology:input.chronology||'UNKNOWN_CHRONOLOGY'};await analytics.capture('epub_export_started',{selected_article_count:selection.articleIds.length});try{const assets=await hydrateImageAssets(db.imageAssets||[],imageDir),book=assembleBook(source,selection,db.items,{imageAssets:assets}),name=`book-${idFor(Date.now()+'')}.epub`,buffer=renderBookEpub(book);await fs.writeFile(path.join(artifacts,name),buffer);const refs=book.chapters.flatMap(x=>x.blocks.filter(b=>b.type==='image')),skipped=refs.filter(b=>b.imageState!=='available').length;await analytics.capture('epub_export_completed',{selected_article_count:book.chapters.length,word_count:book.wordCount,packaged_image_count:book.images.length,skipped_image_count:skipped,artifact_bytes:buffer.length,chronology_status:selection.chronology});return send(res,200,{filename:name,download:`/api/download/${name}`,chapters:book.chapters.length,words:book.wordCount,publicPreviews:book.publicPreviews,imagesPackaged:book.images.length,imagesSkipped:skipped,fileSize:buffer.length})}catch(error){await analytics.capture('epub_export_failed',{failure_category:'export_error'});throw error}}
  if(req.url.startsWith('/api/download/')){const name=path.basename(req.url.slice('/api/download/'.length));if(!/^[a-z0-9-]+\.epub$/.test(name))return send(res,400,{error:'Invalid artifact'});res.writeHead(200,{'content-type':'application/epub+zip','content-disposition':`attachment; filename="${name}"`});return res.end(await fs.readFile(path.join(artifacts,name)))}
  if(req.url==='/api/export/brian.epub'){const db=await readDb(),items=db.items.filter(x=>assessArticle(x).eligible&&(x.source===BRIAN_EXPORT_SOURCE||x.source?.archiveUrl===BRIAN_EXPORT_SOURCE)).sort((a,b)=>(Date.parse(a.date)||Infinity)-(Date.parse(b.date)||Infinity)),assets={};for(const item of items)for(const block of item.blocks||[]){if(block.type!=='image'||assets[block.src])continue;try{const r=await fetch(block.src);if(r.ok){const bytes=Buffer.from(await r.arrayBuffer()),ext=(block.src.match(/\.(png|jpe?g|gif|webp)(?:\?|$)/i)?.[1]||'jpg').toLowerCase(),name=`images/image-${Object.keys(assets).length+1}.${ext}`;assets[block.src]={path:name,bytes,mime:ext==='png'?'image/png':ext==='gif'?'image/gif':ext==='webp'?'image/webp':'image/jpeg'}}}catch{}}res.writeHead(200,{'content-type':'application/epub+zip','content-disposition':'attachment; filename="brian-balfour-essays.epub"'});return res.end(epubBuffer(items,assets))}
  const file=path.join(root,'public',req.url==='/'?'index.html':req.url);let body=await fs.readFile(file);if(hostedMode&&req.url==='/')body=Buffer.from(body.toString().replace('window.BTB_HOSTED=false','window.BTB_HOSTED=true'));return send(res,200,body,file.endsWith('.js')?'text/javascript':'text/html');
}catch(error){send(res,500,{error:error.message})}});
server.listen(process.env.PORT||4173,hostedMode?(process.env.BTB_HOSTED_BIND||'127.0.0.1'):'127.0.0.1',()=>{analytics.capture('app_started');console.log('BlogToBook Brian prototype http://localhost:'+(process.env.PORT||4173))});
