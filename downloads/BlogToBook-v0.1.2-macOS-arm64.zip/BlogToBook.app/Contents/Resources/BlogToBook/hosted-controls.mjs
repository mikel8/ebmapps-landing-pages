export function createHostedQueue({capacity=8,concurrency=1,exportConcurrency=1,onLimit=()=>{}}={}){
  capacity=Math.max(1,Number(capacity));concurrency=Math.max(1,Number(concurrency));exportConcurrency=Math.max(1,Number(exportConcurrency));
  const pending=[];let active=0,activeExports=0,completed=0,failed=0;
  const snapshot=()=>({capacity,concurrency,exportConcurrency,pending:pending.length,active,activeExports,completed,failed});
  const canAccept=()=>pending.length+active<capacity;
  const drain=()=>{while(active<concurrency){const index=pending.findIndex(x=>x.kind!=='export'||activeExports<exportConcurrency);if(index<0)return;const [{task,kind}]=pending.splice(index,1);active++;if(kind==='export')activeExports++;Promise.resolve().then(task).then(()=>completed++,()=>failed++).finally(()=>{active--;if(kind==='export')activeExports--;drain()})}};
  const enqueue=(task,{kind='processing'}={})=>{if(!canAccept()){onLimit(snapshot());return false}pending.push({task,kind});drain();return true};
  return {enqueue,canAccept,snapshot};
}
