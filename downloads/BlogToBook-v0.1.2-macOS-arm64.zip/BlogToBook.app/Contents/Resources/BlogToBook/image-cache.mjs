import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

export const IMAGE_LIMITS={maxImages:500,maxBytes:50*1024*1024,concurrency:4,timeoutMs:15000};
const typeFor={'image/jpeg':'jpg','image/png':'png','image/gif':'gif','image/webp':'webp'};
const hash=s=>createHash('sha256').update(s).digest('hex').slice(0,24);

export function selectSrcset(value,base){
  const input=String(value||''),choices=[...input.matchAll(/(?:^|,\s*)(\S+)\s+(\d+(?:\.\d+)?)([wx])(?=\s*(?:,|$))/g)].map(match=>({url:match[1],size:Number(match[2]),unit:match[3]}));
  if(!choices.length&&input.trim()&&!input.includes(','))choices.push({url:input.trim(),size:0,unit:''});
  if(!choices.length)return null;
  choices.sort((a,b)=>(a.unit===b.unit?b.size-a.size:a.unit==='w'?-1:1));
  return resolveImageUrl(choices[0].url,base);
}
export function resolveImageUrl(raw,base){try{const u=new URL(raw,base);if(!/^https?:$/.test(u.protocol))return null;u.hash='';return u.href}catch{return null}}
export function imageCandidate(block,base){
  const src=selectSrcset(block.srcset||block['data-srcset'],base)||resolveImageUrl(block.src||block['data-src']||block['data-lazy-src']||block['data-image'],base);
  if(!src)return {state:'rejected',reason:'MALFORMED_URL'};
  if(Number(block.width)===1&&Number(block.height)===1)return {state:'rejected',reason:'TRACKING_PIXEL',originalUrl:src,alt:block.alt||''};
  const clue=`${src} ${block.alt||''}`.toLowerCase();
  if(/(?:tracking|analytics|pixel|spacer|\/avatar(?:s)?\/|profile_picture|\/logo(?:\/|\.|_))/i.test(clue)||/\b(?:avatar|profile picture|site logo)\b/i.test(clue))return {state:'rejected',reason:'NON_CONTENT_ASSET',originalUrl:src,alt:block.alt||''};
  return {state:'pending',originalUrl:src,alt:block.alt||'',caption:block.caption||'',id:hash(src)};
}
function mime(response){return String(response.headers.get('content-type')||'').split(';')[0].toLowerCase()}
async function fetchOne(candidate,{assets,imageDir,fetchImpl,remaining,limits,canFetch}){
  const existing=assets.find(x=>x.id===candidate.id&&x.state==='available');
  if(existing){try{await fs.access(path.join(imageDir,existing.fileName));return {...existing,reused:true}}catch{}}
  if(remaining.count>=limits.maxImages)return {...candidate,state:'skipped',reason:'IMAGE_COUNT_LIMIT'};
  if(canFetch&&!canFetch())return {...candidate,state:'skipped',reason:'JOB_BUDGET_EXHAUSTED'};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),limits.timeoutMs);
  try{
    const response=await fetchImpl(candidate.originalUrl,{signal:controller.signal,redirect:'follow',purpose:'image'});
    if(!response.ok)return {...candidate,state:'failed',reason:`HTTP_${response.status}`};
    const finalUrl=resolveImageUrl(response.url,candidate.originalUrl);if(!finalUrl)return {...candidate,state:'failed',reason:'UNSAFE_REDIRECT'};
    const mediaType=mime(response),ext=typeFor[mediaType];if(!ext)return {...candidate,state:'skipped',reason:'UNSUPPORTED_MEDIA_TYPE',mediaType};
    const bytes=Buffer.from(await response.arrayBuffer());
    if(!bytes.length)return {...candidate,state:'failed',reason:'EMPTY_IMAGE',mediaType};
    if(remaining.bytes+bytes.length>limits.maxBytes)return {...candidate,state:'skipped',reason:'IMAGE_BYTE_LIMIT',mediaType};
    await fs.mkdir(imageDir,{recursive:true});const fileName=`${candidate.id}.${ext}`,tmp=path.join(imageDir,`${fileName}.tmp`);
    await fs.writeFile(tmp,bytes);await fs.rename(tmp,path.join(imageDir,fileName));remaining.bytes+=bytes.length;remaining.count++;
    return {...candidate,state:'available',finalUrl,mediaType,fileName,byteSize:bytes.length,acquiredAt:new Date().toISOString()};
  }catch(error){const budget=error?.code==='JOB_BUDGET_EXCEEDED'||error?.code==='JOB_DEADLINE_EXCEEDED';return {...candidate,state:budget?'skipped':'failed',reason:budget?error.code:error?.name==='AbortError'?'TIMEOUT':'FETCH_FAILED'} }finally{clearTimeout(timer)}
}
export async function acquireImages(items,{assets=[],imageDir,fetchImpl=fetch,concurrency=IMAGE_LIMITS.concurrency,limits=IMAGE_LIMITS,canFetch}={}){
  const refs=[];for(const article of items)for(const block of article.contentBlocks||article.blocks||[])if(block.type==='image')refs.push({article,block,candidate:imageCandidate(block,article.canonicalUrl||article.url)});
  const byId=new Map();for(const ref of refs)if(ref.candidate.state==='pending'&&!byId.has(ref.candidate.id))byId.set(ref.candidate.id,ref.candidate);
  const remaining={count:0,bytes:0};let cursor=0;const values=[...byId.values()],results=new Map();
  await Promise.all(Array.from({length:Math.min(concurrency,values.length)},async()=>{while(cursor<values.length){const candidate=values[cursor++];results.set(candidate.id,await fetchOne(candidate,{assets,imageDir,fetchImpl,remaining,limits,canFetch}))}}));
  const stats={discovered:refs.length,downloaded:0,reused:0,rejected:0,failed:0,skipped:0,bytes:0},counted=new Set();
  for(const ref of refs){const asset=ref.candidate.state==='pending'?results.get(ref.candidate.id):ref.candidate,key=asset.id||`${asset.reason}:${asset.originalUrl||''}`;Object.assign(ref.block,{imageId:asset.id||null,imageState:asset.state,imageReason:asset.reason||null,originalUrl:asset.originalUrl||null,alt:asset.alt||ref.block.alt||'',caption:asset.caption||''});if(!counted.has(key)){counted.add(key);if(asset.state==='available'){if(asset.reused)stats.reused++;else {stats.downloaded++;stats.bytes+=asset.byteSize||0}}else if(asset.state==='rejected')stats.rejected++;else if(asset.state==='failed')stats.failed++;else stats.skipped++}if(asset.state==='available'){if(!assets.some(x=>x.id===asset.id))assets.push({...asset,reused:undefined,articleIds:[ref.article.id].filter(Boolean)});else {const record=assets.find(x=>x.id===asset.id);record.articleIds=[...new Set([...(record.articleIds||[]),ref.article.id].filter(Boolean))]}}}
  for(const article of items)article.imageReferences=(article.contentBlocks||article.blocks||[]).filter(x=>x.type==='image');
  return {assets,stats};
}
export async function hydrateImageAssets(assets=[],imageDir){const out=[];for(const asset of assets)if(asset.state==='available'&&asset.fileName){try{out.push({...asset,bytes:await fs.readFile(path.join(imageDir,asset.fileName))})}catch{}}return out}
