import {resolveUrl} from './engine.mjs';
import {articleCandidate} from './pipeline.mjs';
import {decodeHtmlEntities} from './text-normalize.mjs';

function preloadData(html){
  const match=html.match(/window\._preloads\s*=\s*JSON\.parse\(("(?:\\.|[^"\\])*")\)/);
  if(!match)return null;
  try{return JSON.parse(JSON.parse(match[1]))}catch{return null}
}
function declaredPosts(html){const value=preloadData(html)?.newPostsForArchive?.pub;return Array.isArray(value)?value:[]}
function candidateFromPost(source,post,index,page){const raw=post?.canonical_url||post?.url||(post?.slug?`/p/${post.slug}`:'');const url=resolveUrl(raw,source.archiveUrl,source.origin);if(!url||!String(post?.title||'').trim())return null;return articleCandidate({url,title:decodeHtmlEntities(post.title),date:post.post_date||post.published_at||post.date||'',author:decodeHtmlEntities(post.author_name||''),blocks:[],words:0,status:'metadata only'},{source,provenance:{executor:'declared archive-data continuation',structure:'declared archive record',index,archivePage:page}})}
const sameOrigin=(url,source)=>{try{return new URL(url).origin===source.origin}catch{return false}};

export function hasDeclaredArchiveData(html){return declaredPosts(html).length>0}

export async function discoverDeclaredArchive(source,html,{firstUrl=source.archiveUrl,fetchPage=async url=>{const response=await fetch(url);return {ok:response.ok,status:response.status,url:response.url,text:await response.text()}},maxPages=50,maxCandidates=5000}={}){
  const initial=declaredPosts(html);if(!initial.length)return null;
  const pageSize=initial.length,pages=[{url:firstUrl,count:initial.length}],all=new Map(),warnings=[];let termination='',offset=initial.length,requests=0;
  const add=(posts,page,start)=>posts.forEach((post,index)=>{const candidate=candidateFromPost(source,post,start+index,page);if(candidate&&!all.has(candidate.canonicalUrl))all.set(candidate.canonicalUrl,candidate)});add(initial,firstUrl,0);
  while(pages.length<maxPages&&all.size<maxCandidates){const endpoint=new URL('/api/v1/archive',source.origin);endpoint.searchParams.set('sort','new');endpoint.searchParams.set('search','');endpoint.searchParams.set('offset',String(offset));endpoint.searchParams.set('limit',String(pageSize));let response;requests++;try{response=await fetchPage(endpoint.href)}catch{termination='FETCH_FAILED';warnings.push('Declared archive continuation could not be fetched');break}if(!response?.ok){termination=response?.status===404?'UNSUPPORTED_CONTINUATION':'FETCH_FAILED';warnings.push(`Declared archive continuation returned HTTP ${response?.status||'unknown'}`);break}const final=response.url||endpoint.href;if(!sameOrigin(final,source)){termination='REDIRECT_BLOCKED';warnings.push('Declared archive continuation redirected outside the selected source origin');break}let posts;try{posts=JSON.parse(response.text||'[]')}catch{termination='UNSUPPORTED_CONTINUATION';warnings.push('Declared archive continuation was not valid JSON');break}if(!Array.isArray(posts)){termination='UNSUPPORTED_CONTINUATION';warnings.push('Declared archive continuation did not return an article list');break}pages.push({url:final,count:posts.length});add(posts,final,offset);offset+=posts.length;if(posts.length<pageSize){termination='EXHAUSTED_VERIFIED';break}}
  if(!termination)termination=all.size>=maxCandidates?'CANDIDATE_LIMIT':'PAGE_LIMIT';if(termination==='CANDIDATE_LIMIT')warnings.push(`Candidate safety limit (${maxCandidates}) reached`);if(termination==='PAGE_LIMIT')warnings.push(`Page safety limit (${maxPages}) reached`);
  const completeness=termination==='EXHAUSTED_VERIFIED'?{status:'COMPLETE',reason:'the declared public archive returned a final short page',verified:true,inferred:false}:{status:'PARTIAL',reason:termination,verified:false,inferred:false},raw=pages.reduce((sum,page)=>sum+page.count,0),diagnostics={executor:'declared archive-data continuation',pagesFetched:pages.length,pageUrls:pages.map(page=>page.url),candidatesPerPage:pages.map(page=>page.count),rawCandidates:raw,finalCandidates:Math.min(all.size,maxCandidates),duplicatesRemoved:raw-all.size,continuationStrategiesAttempted:['declared public archive-data offset'],continuationRequests:requests,terminationReason:termination,limits:{maxPages,maxCandidates},limitsReached:{page:termination==='PAGE_LIMIT',candidate:termination==='CANDIDATE_LIMIT'},continuationRequestsFailed:['FETCH_FAILED','REDIRECT_BLOCKED','UNSUPPORTED_CONTINUATION'].includes(termination),completeness,evidence:['page-declared archive record set','same-origin bounded public archive continuation']};
  return {candidates:[...all.values()].slice(0,maxCandidates),diagnostics,warnings};
}
