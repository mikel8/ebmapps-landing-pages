import sharp from 'sharp';
import {createHash} from 'node:crypto';

sharp.cache({memory:64,files:0,items:32});
sharp.concurrency(1);

export const IMAGE_EXPORT_MODES=Object.freeze({TEXT_ONLY:'text-only',OPTIMIZED:'optimized',ORIGINAL:'original'});
export const IMAGE_POLICY=Object.freeze({maxDimension:1600,jpegQuality:82,pngQuality:90,webpQuality:82,maxInputBytes:25*1024*1024,maxPixels:40_000_000,maxAnimatedBytes:2*1024*1024,maxOutputBytes:150*1024*1024,warningBytes:100*1024*1024});
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const extOf=x=>String(x.fileName||'').split('.').pop().toLowerCase();
const omission=(asset,reason)=>({id:asset.id,reason,originalUrl:asset.originalUrl});

export async function prepareExportImages(images=[],mode=IMAGE_EXPORT_MODES.OPTIMIZED,policy=IMAGE_POLICY){
  if(!Object.values(IMAGE_EXPORT_MODES).includes(mode))throw Error('Unsupported EPUB image mode.');
  const unique=new Map(),aliases=new Map(),omitted=[];
  let optimized=0,original=0,outputBytes=0,duplicateBytesSaved=0,failed=0,gifsOmitted=0,resourceLimited=0;
  const originalBytes=images.reduce((n,x)=>n+(x.bytes?.length||0),0);
  if(mode===IMAGE_EXPORT_MODES.TEXT_ONLY)return {images:[],aliases,omitted:images.map(x=>omission(x,'TEXT_ONLY')),stats:{mode,packaged:0,omitted:images.length,optimized:0,original:0,failed:0,gifsOmitted:0,resourceLimited:0,originalBytes,outputBytes:0,duplicateBytesSaved:0}};
  for(const asset of images){
    if(!Buffer.isBuffer(asset.bytes)||!asset.bytes.length){omitted.push(omission(asset,'MISSING_IMAGE_BYTES'));failed++;continue}
    const key=digest(asset.bytes),prior=unique.get(key);
    if(prior){aliases.set(asset.id,prior.id);duplicateBytesSaved+=asset.bytes.length;continue}
    if(mode===IMAGE_EXPORT_MODES.ORIGINAL){unique.set(key,asset);original++;outputBytes+=asset.bytes.length;continue}
    if(asset.bytes.length>policy.maxInputBytes){omitted.push(omission(asset,'IMAGE_INPUT_LIMIT'));failed++;resourceLimited++;continue}
    try{
      const metadata=await sharp(asset.bytes,{failOn:'error',limitInputPixels:policy.maxPixels,animated:true}).metadata();
      const animated=(metadata.pages||1)>1;
      if(extOf(asset)==='gif'&&animated&&asset.bytes.length>policy.maxAnimatedBytes){omitted.push(omission(asset,'OVERSIZED_ANIMATED_GIF'));gifsOmitted++;continue}
      if(extOf(asset)==='gif'){unique.set(key,asset);original++;outputBytes+=asset.bytes.length;continue}
      let image=sharp(asset.bytes,{failOn:'error',limitInputPixels:policy.maxPixels});
      if((metadata.width||0)>policy.maxDimension||(metadata.height||0)>policy.maxDimension)image=image.resize({width:policy.maxDimension,height:policy.maxDimension,fit:'inside',withoutEnlargement:true});
      let bytes,fileName,mediaType;
      if(metadata.hasAlpha){bytes=await image.webp({quality:policy.webpQuality,effort:4}).toBuffer();fileName=`${asset.id}.webp`;mediaType='image/webp'}
      else {bytes=await image.jpeg({quality:policy.jpegQuality,mozjpeg:true}).toBuffer();fileName=`${asset.id}.jpg`;mediaType='image/jpeg'}
      const out={...asset,bytes,fileName,mediaType};unique.set(key,out);optimized++;outputBytes+=bytes.length;
    }catch{omitted.push(omission(asset,'IMAGE_PROCESSING_FAILED'));failed++}
  }
  return {images:[...unique.values()],aliases,omitted,stats:{mode,packaged:unique.size,omitted:omitted.length,optimized,original,failed,gifsOmitted,resourceLimited,originalBytes,outputBytes,duplicateBytesSaved}};
}
