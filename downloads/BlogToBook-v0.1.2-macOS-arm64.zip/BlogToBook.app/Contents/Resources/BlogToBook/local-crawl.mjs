import {runCrawl,processCandidate} from './crawler.mjs';

// Article crawl completion is deliberately independent of optional image
// acquisition. Review backfill handles images after every article work unit
// has reached a terminal state.
export function runLocalArticleCrawl(job,{cache,persist,concurrency=3}={}){
  return runCrawl(job,{cache,persist,concurrency,process:candidate=>processCandidate(candidate,cache)});
}
