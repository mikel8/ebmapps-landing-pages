const named=Object.freeze({
  amp:'&',AMP:'&',lt:'<',LT:'<',gt:'>',GT:'>',quot:'"',QUOT:'"',apos:"'",nbsp:'\u00a0',
  ensp:'\u2002',emsp:'\u2003',thinsp:'\u2009',zwnj:'\u200c',zwj:'\u200d',lrm:'\u200e',rlm:'\u200f',
  ndash:'–',mdash:'—',lsquo:'‘',rsquo:'’',sbquo:'‚',ldquo:'“',rdquo:'”',bdquo:'„',hellip:'…',
  bull:'•',middot:'·',laquo:'«',raquo:'»',lsaquo:'‹',rsaquo:'›',copy:'©',reg:'®',trade:'™',
  euro:'€',pound:'£',yen:'¥',cent:'¢',sect:'§',para:'¶',deg:'°',plusmn:'±',times:'×',divide:'÷',
  iexcl:'¡',iquest:'¿',micro:'µ',acute:'´',frac14:'¼',frac12:'½',frac34:'¾',
  Agrave:'À',Aacute:'Á',Acirc:'Â',Atilde:'Ã',Auml:'Ä',Aring:'Å',AElig:'Æ',Ccedil:'Ç',
  Egrave:'È',Eacute:'É',Ecirc:'Ê',Euml:'Ë',Igrave:'Ì',Iacute:'Í',Icirc:'Î',Iuml:'Ï',
  ETH:'Ð',Ntilde:'Ñ',Ograve:'Ò',Oacute:'Ó',Ocirc:'Ô',Otilde:'Õ',Ouml:'Ö',Oslash:'Ø',
  Ugrave:'Ù',Uacute:'Ú',Ucirc:'Û',Uuml:'Ü',Yacute:'Ý',THORN:'Þ',szlig:'ß',
  agrave:'à',aacute:'á',acirc:'â',atilde:'ã',auml:'ä',aring:'å',aelig:'æ',ccedil:'ç',
  egrave:'è',eacute:'é',ecirc:'ê',euml:'ë',igrave:'ì',iacute:'í',icirc:'î',iuml:'ï',
  eth:'ð',ntilde:'ñ',ograve:'ò',oacute:'ó',ocirc:'ô',otilde:'õ',ouml:'ö',oslash:'ø',
  ugrave:'ù',uacute:'ú',ucirc:'û',uuml:'ü',yacute:'ý',thorn:'þ',yuml:'ÿ'
});

function scalar(value){const point=Number(value);return Number.isInteger(point)&&point>0&&point<=0x10ffff&&!(point>=0xd800&&point<=0xdfff)?String.fromCodePoint(point):null}

/** Decode one layer of semicolon-terminated HTML character references. */
export function decodeHtmlEntities(value){return String(value??'').replace(/&(?:#(\d+)|#x([0-9a-f]+)|([a-z][a-z0-9]+));/gi,(entity,decimal,hex,name)=>{const decoded=decimal?scalar(Number(decimal)):hex?scalar(Number.parseInt(hex,16)):named[name];return decoded??entity})}

export function htmlText(value){return decodeHtmlEntities(String(value??'').replace(/<[^>]+>/g,' ')).replace(/\s+/g,' ').trim()}
