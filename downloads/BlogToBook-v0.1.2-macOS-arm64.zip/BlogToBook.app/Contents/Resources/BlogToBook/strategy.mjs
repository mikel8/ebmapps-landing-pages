export const STRATEGIES=['article-link archive','inline multi-article archive','static-link archive','feed-assisted archive','paginated archive','load-more/infinite-scroll candidate','RSS/feed-assisted candidate','sitemap-assisted candidate','single-article candidate','unsupported/unknown'];
export function selectDiscoveryStrategy(inspection){
  const capabilities=[],evidence=[],alternatives=[],warnings=[];
  const hasPagination=inspection.pagination.relNext.length||inspection.pagination.numberedPages||inspection.pagination.olderNewer;
  if(hasPagination){capabilities.push('pagination');evidence.push('pagination navigation detected')}
  if(inspection.articleElements>1){evidence.push(`${inspection.articleElements} repeated article blocks`);if(inspection.dateEvidence)evidence.push('publication-date evidence detected');return {primary:'inline multi-article archive',confidence:Math.min(0.95,.55+inspection.articleElements*.05+(hasPagination ? .2 : 0)),capabilities,evidence,alternatives:inspection.likelyArticleLinks.length?['article-link archive']:[],warnings}}
  if(inspection.likelyArticleLinks.length>=2||inspection.jsonLd.urls.length>=2){evidence.push(`${Math.max(inspection.likelyArticleLinks.length,inspection.jsonLd.urls.length)} likely article links`);return {primary:'article-link archive',confidence:.7,capabilities,evidence,alternatives:hasPagination?['paginated archive']:[],warnings:[]}}
  if(inspection.feeds.length){return {primary:'feed-assisted archive',confidence:.65,capabilities,evidence:[`${inspection.feeds.length} public RSS/Atom feed reference${inspection.feeds.length===1?'':'s'} detected`],alternatives:[],warnings:[]}}
  if((inspection.genericStaticLinks||[]).length>=3){return {primary:'static-link archive',confidence:.55,capabilities,evidence:[`${inspection.genericStaticLinks.length} high-level same-origin static links detected`],alternatives:[],warnings:[]}}
  if(inspection.loadMore){return {primary:'load-more/infinite-scroll candidate',confidence:.55,capabilities,evidence:['static load-more/infinite-scroll indicator detected'],alternatives:[],warnings:['JavaScript-driven discovery is not implemented']}}
  if(inspection.sitemaps.length){return {primary:'sitemap-assisted candidate',confidence:.45,capabilities,evidence:['sitemap reference detected'],alternatives:[],warnings:['Sitemap-assisted discovery is not implemented']}}
  if(inspection.articleElements===1){return {primary:'single-article candidate',confidence:.5,capabilities,evidence:['one article element detected'],alternatives:[],warnings:['The supplied URL does not appear to be an archive']}}
  return {primary:'unsupported/unknown',confidence:.1,capabilities,evidence,alternatives,warnings:['Insufficient static archive evidence']};
}
