import {createJob,processCandidate,reconcile,runCrawl} from './crawler.mjs';
import {acquireImages} from './image-cache.mjs';

const failed=new Set(['FAILED_FETCH','FAILED_EXTRACTION','SKIPPED']);

export function hostedFailureRecords(crawl){
  return crawl.work.filter(work=>failed.has(work.outcome)).map(work=>({
    title:work.title||'Untitled article',
    outcome:work.outcome,
    category:work.failure?.category||'FETCH_FAILED',
    message:work.failure?.message||'This article could not be collected.',
    retryAttempts:work.retryAttempts||0
  }));
}

/**
 * Crawl article documents before optional image acquisition. Both phases remain
 * inside the same guarded job and therefore share the existing hard ceiling.
 * Deferral ensures optional images cannot consume capacity required to collect
 * the selected article bodies.
 */
export async function runHostedCrawl({job,candidates,articles,assets,imageDir,fetchGuard,persist=async()=>{},imageLimits,maxRetries=1}={}){
  const crawl=createJob(job.source,candidates,job.id);
  let imageStats={discovered:0,downloaded:0,reused:0,rejected:0,failed:0,skipped:0,bytes:0};
  const save=async(extra={})=>persist({crawl,imageStats,...extra,failures:hostedFailureRecords(crawl),budget:fetchGuard.metrics(job.id)});
  await fetchGuard.withJob(job,async()=>{
    await runCrawl(crawl,{cache:articles,maxRetries,process:candidate=>processCandidate(candidate,articles,{maxRetries}),persist:async()=>save()});
    if(!crawl.cancelRequested){
      imageStats=(await acquireImages(articles,{assets,imageDir,limits:imageLimits,canFetch:()=>fetchGuard.remainingFor(job.id)>0})).stats;
      await save({imagesComplete:true});
    }
  });
  return {crawl,imageStats,budget:fetchGuard.metrics(job.id),failures:hostedFailureRecords(crawl),reconciliation:reconcile(crawl)};
}
