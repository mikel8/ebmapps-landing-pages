import {sourceConfig} from './pipeline.mjs';

export function sourceFromInput(value){
  if(typeof value!=='string'||!value.trim())throw Error('An archive URL is required');
  let url;
  try{url=new URL(value.trim())}catch{throw Error('A valid http:// or https:// archive URL is required')}
  if(url.protocol!=='http:'&&url.protocol!=='https:')throw Error('A valid http:// or https:// archive URL is required');
  return sourceConfig({archiveUrl:url.href});
}
