import path from 'node:path';

/** Resolve writable runtime locations without coupling them to app resources. */
export function runtimePaths({root, dataDir=process.env.BTB_DATA_DIR, artifactsDir=process.env.BTB_ARTIFACTS_DIR}={}) {
  const sourceRoot=root || process.cwd();
  const data=path.resolve(dataDir || path.join(sourceRoot,'data'));
  return {data, dbFile:path.join(data,'cache.json'), imageDir:path.join(data,'images'), artifacts:path.resolve(artifactsDir || path.join(sourceRoot,'artifacts'))};
}
