export const EXTRACTION_QUALITY_VERSION=1;
export const CONTENT_OUTCOMES=Object.freeze({FULL_ARTICLE:'FULL_ARTICLE',PUBLIC_PREVIEW:'PUBLIC_PREVIEW',METADATA_ONLY:'METADATA_ONLY',UNSUPPORTED:'UNSUPPORTED',EXTRACTION_FAILED:'EXTRACTION_FAILED'});

const placeholder=/^(?:untitled|unknown|n\/?a)$/i;
const bodyOf=article=>article?.contentBlocks||article?.blocks||[];
const textOf=blocks=>blocks.filter(block=>typeof block?.text==='string').map(block=>block.text.trim()).filter(Boolean).join(' ');
const validUrl=value=>{try{const url=new URL(value);return /^https?:$/.test(url.protocol)}catch{return false}};

export function contentOutcome(article){
  const classification=String(article?.classification||article?.status||'').toLowerCase();
  if(article?.diagnostics?.extractionFailed||['network error','rate-limited'].includes(classification))return CONTENT_OUTCOMES.EXTRACTION_FAILED;
  if(classification==='public preview')return CONTENT_OUTCOMES.PUBLIC_PREVIEW;
  if(classification==='metadata only')return CONTENT_OUTCOMES.METADATA_ONLY;
  if(classification==='full article')return CONTENT_OUTCOMES.FULL_ARTICLE;
  return CONTENT_OUTCOMES.UNSUPPORTED;
}

export function assessArticle(article,{requireCurrentVersion=true}={}){
  const blocks=bodyOf(article),text=textOf(blocks),hasBody=!!text||blocks.some(block=>block?.type==='image'&&block?.src);
  const identity=!!article?.source?.sourceId&&validUrl(article?.canonicalUrl||article?.canonical||article?.url)&&!!String(article?.title||'').trim()&&!placeholder.test(String(article?.title||'').trim());
  const diagnostics=article?.diagnostics||{},corrupt=diagnostics.corrupt===true||diagnostics.archiveContamination===true||diagnostics.confirmedArchiveIndexContamination===true;
  const structuralEvidence=!!diagnostics.selectedBoundary&&!corrupt;
  let outcome=contentOutcome(article);
  if(outcome===CONTENT_OUTCOMES.FULL_ARTICLE&&(!identity||!hasBody||!structuralEvidence))outcome=CONTENT_OUTCOMES.UNSUPPORTED;
  if(outcome===CONTENT_OUTCOMES.PUBLIC_PREVIEW&&(!identity||!hasBody||diagnostics.previewFound!==true))outcome=CONTENT_OUTCOMES.UNSUPPORTED;
  const currentVersion=article?.extractionQualityVersion===EXTRACTION_QUALITY_VERSION;
  const eligible=(outcome===CONTENT_OUTCOMES.FULL_ARTICLE||outcome===CONTENT_OUTCOMES.PUBLIC_PREVIEW)&&(!requireCurrentVersion||currentVersion);
  return {outcome,eligible,reusable:eligible,currentVersion,identity,hasBody,structuralEvidence,corrupt};
}

export function stampExtractionQuality(article){
  const stamped={...article,extractionQualityVersion:EXTRACTION_QUALITY_VERSION};
  return {...stamped,contentOutcome:assessArticle(stamped,{requireCurrentVersion:false}).outcome};
}
