import {resolveUrl} from './engine.mjs';
import {articleCandidate} from './pipeline.mjs';
import {htmlText} from './text-normalize.mjs';

const clean=htmlText;
const ignoredTitle=/^(?:home|about(?:\s+me)?|contact(?:\s+me)?|archive|blog|posts?|categories?|tags?|authors?|search|subscribe|newsletter|rss|next|previous|older|newer|read more|more|menu|login|sign[ -]?in|sign[ -]?up)$/i;
const ignoredPath=/\/(?:about|contact|privacy|terms|login|sign-?in|sign-?up|account|author|authors|tag|tags|category|categories|me|shelves|library)(?:\/|$)|\.(?:png|jpe?g|gif|svg|css|js|pdf|xml)$/i;
const attr=(tag,name)=>new RegExp(`\\b${name}\\s*=\\s*["']([^"']*)`,'i').exec(tag)?.[1]||'';
function nearbyDate(html,index){const window=html.slice(Math.max(0,index-350),index+450);return attr(window.match(/<time\b[^>]*>/i)?.[0]||'','datetime')||clean(window.match(/<time\b[^>]*>([\s\S]*?)<\/time>/i)?.[1]||'')}
function score({url,title,raw,index,html}){let value=0;if(title.length>=8)value+=2;if(title.split(/\s+/).length>=2)value++;if(/<h[1-4]\b/i.test(raw)||/<h[1-4]\b[^>]*>[\s\S]{0,500}$/i.test(html.slice(Math.max(0,index-700),index)))value+=2;if(/\.[a-z0-9]{2,5}$/i.test(new URL(url).pathname)||new URL(url).pathname.split('/').filter(Boolean).length>=2)value++;if(nearbyDate(html,index))value++;return value}
export function staticLinkEvidence(source,html){return discoverStaticLinks(source,html,{minimum:Infinity}).diagnostics}
export function discoverStaticLinks(source,html,{minimum=3}={}){
  const seen=new Map(),rejected=[];let index=0;
  for(const match of html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)){const raw=match[0],href=attr(match[1],'href'),title=clean(match[2]);let url;try{url=resolveUrl(href,source.archiveUrl,source.origin)}catch{};const root=url===source.origin+'/'||url===source.archiveUrl;
    if(!url||root||ignoredPath.test(new URL(url).pathname)||ignoredTitle.test(title)||title.length<4){rejected.push({href,title,reason:'negative evidence'});index++;continue}
    const value=score({url,title,raw,index:match.index,html});if(value<3){rejected.push({href,title,reason:'weak structural evidence'});index++;continue}
    const date=nearbyDate(html,match.index),excerpt=clean(html.slice(match.index+raw.length,match.index+raw.length+500).match(/<p\b[^>]*>([\s\S]*?)<\/p>/i)?.[1]||'');const candidate=articleCandidate({url,title,date,blocks:excerpt?[{type:'p',text:excerpt}]:[],words:excerpt?excerpt.split(/\s+/).length:0,status:'metadata only'},{source,provenance:{executor:'static-link archive',structure:'scored same-origin anchor',score:value,index}});const old=seen.get(url);if(!old||candidate.provenance.score>old.provenance.score)seen.set(url,candidate);index++;
  }
  const candidates=[...seen.values()];const diagnostics={executor:'static-link archive',scoredAnchors:index,accepted:candidates.length,rejected:rejected.length,minimumScore:3,evidence:['same-origin anchors','meaningful titles','path diversity/heading/date scoring']};return {candidates:candidates.length>=minimum?candidates:[],diagnostics,warnings:candidates.length<minimum?['Insufficient high-confidence static article-link evidence']:[]}
}
