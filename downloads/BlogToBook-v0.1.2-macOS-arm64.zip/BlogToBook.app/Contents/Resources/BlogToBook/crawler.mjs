import {extractCandidate} from './extraction.mjs';
import {upsertCachedArticle,validCachedArticle} from './cache.mjs';
import {assessArticle,CONTENT_OUTCOMES} from './quality.mjs';

export const OUTCOMES=['SUCCESS','REUSED','PUBLIC_PREVIEW','REUSED_PREVIEW','FAILED_FETCH','FAILED_EXTRACTION','SKIPPED','CANCELLED'];

const failureFor=(article,outcome)=>{
  const diagnostics=article?.diagnostics||{};
  if(outcome==='FAILED_EXTRACTION'&&!diagnostics.extractionFailed)return {category:'EXTRACTION_UNSUPPORTED',message:'This page did not contain a supported article body.',retryable:false};
  return {category:diagnostics.failureCategory||'FETCH_FAILED',code:diagnostics.failureCode||'FETCH_FAILED',message:diagnostics.failureMessage||'This article could not be collected.',retryable:diagnostics.retryable===true};
};

export function reconcile(job){
  const r=Object.fromEntries(OUTCOMES.map(x=>[x,0]));
  for(const w of job.work)if(w.outcome&&Object.hasOwn(r,w.outcome))r[w.outcome]++;
  const terminal=Object.values(r).reduce((a,b)=>a+b,0);
  return {total:job.work.length,...r,fullArticles:r.SUCCESS+r.REUSED,previews:r.PUBLIC_PREVIEW+r.REUSED_PREVIEW,failed:r.FAILED_FETCH+r.FAILED_EXTRACTION+r.SKIPPED,terminal,remaining:job.work.length-terminal,invariantSatisfied:terminal===job.work.length};
}

export function createJob(source,candidates,id){
  const u=[...new Map(candidates.map(x=>[x.canonicalUrl,x])).values()];
  return {id,state:'READY',source,total:u.length,work:u.map(candidate=>({candidate,canonicalUrl:candidate.canonicalUrl,title:candidate.title,state:'PENDING'})),cancelRequested:false};
}

export function cancelJob(j){j.cancelRequested=true;if(j.state==='READY'||j.state==='RUNNING')j.state='CANCELLED';return j}

export async function runCrawl(job,{cache=[],persist=async()=>{},concurrency=3,process}={}){
  if(job.state==='READY')job.state='RUNNING';
  console.log('[crawl:start]',job.id,job.work.length,'workers',Math.min(concurrency,job.work.length));
  let i=0;
  const work=async()=>{while(!job.cancelRequested&&i<job.work.length){
    const w=job.work[i++];
    if(i<=3)console.log('[crawl:reserve]',job.id,w.canonicalUrl);
    w.state='RUNNING';
    try{
      let r=process?await process(w.candidate,cache):await processCandidate(w.candidate,cache);
      if(r.article){
        const quality=assessArticle(r.article);
        r=quality.outcome===CONTENT_OUTCOMES.FULL_ARTICLE?{...r,outcome:'SUCCESS'}:quality.outcome===CONTENT_OUTCOMES.PUBLIC_PREVIEW?{...r,outcome:'PUBLIC_PREVIEW'}:{...r,outcome:quality.outcome===CONTENT_OUTCOMES.EXTRACTION_FAILED?'FAILED_FETCH':'FAILED_EXTRACTION'};
      }
      w.outcome=r.outcome;
      w.failure=r.failure||null;
      w.retryAttempts=r.retryAttempts||0;
      if(i<=3)console.log('[crawl:cache/outcome]',job.id,w.canonicalUrl,r.outcome);
      if(r.article)cache.splice(0,cache.length,...upsertCachedArticle(cache,r.article,x=>x));
    }catch(error){
      w.outcome='FAILED_FETCH';
      w.failure={category:error?.code==='JOB_BUDGET_EXCEEDED'||error?.code==='JOB_DEADLINE_EXCEEDED'?'RESOURCE_LIMIT':'FETCH_FAILED',message:error?.code==='JOB_BUDGET_EXCEEDED'||error?.code==='JOB_DEADLINE_EXCEEDED'?'This article could not be collected because the job reached its resource limit.':'This article could not be collected.'};
    }
    w.state='TERMINAL';
    await persist(cache,job);
    const r=reconcile(job);
    console.log('[crawl:terminal]',job.id,w.outcome,r.terminal,r.REUSED,r.remaining);
  }};
  await Promise.all(Array.from({length:Math.min(concurrency,job.work.length)},work));
  for(const w of job.work)if(!w.outcome){w.outcome='CANCELLED';w.state='TERMINAL'}
  job.reconciliation=reconcile(job);job.outcomes=job.reconciliation;
  job.state=!job.reconciliation.invariantSatisfied?'FAILED':job.cancelRequested?'CANCELLED':(job.reconciliation.failed)?'COMPLETED_WITH_ERRORS':'COMPLETED';
  console.log('[crawl:done]',job.id,job.state,job.reconciliation);
  await persist(cache,job);
  return job;
}

export async function processCandidate(candidate,cache,{afterAccept=async()=>{},maxRetries=0,retryDelayMs=75}={}){
  const cached=validCachedArticle(cache,candidate.source,candidate,value=>value);
  if(cached){const quality=assessArticle(cached);return {outcome:quality.outcome===CONTENT_OUTCOMES.PUBLIC_PREVIEW?'REUSED_PREVIEW':'REUSED'}}
  for(let attempt=0;;attempt++){
    const article=await extractCandidate(candidate.source,candidate),quality=assessArticle(article);
    if(quality.outcome===CONTENT_OUTCOMES.FULL_ARTICLE){await afterAccept(article);return {outcome:'SUCCESS',article,retryAttempts:attempt}}
    if(quality.outcome===CONTENT_OUTCOMES.PUBLIC_PREVIEW){await afterAccept(article);return {outcome:'PUBLIC_PREVIEW',article,retryAttempts:attempt}}
    const outcome=quality.outcome===CONTENT_OUTCOMES.EXTRACTION_FAILED?'FAILED_FETCH':'FAILED_EXTRACTION',failure=failureFor(article,outcome);
    if(failure.retryable&&attempt<maxRetries){await new Promise(resolve=>setTimeout(resolve,retryDelayMs*(attempt+1)));continue}
    return {outcome,failure,retryAttempts:attempt};
  }
}
